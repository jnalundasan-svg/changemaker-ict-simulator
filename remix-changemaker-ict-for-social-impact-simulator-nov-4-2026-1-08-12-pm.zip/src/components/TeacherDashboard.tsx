import React, { useState, useMemo } from 'react';
import {
  Lock,
  Unlock,
  Users,
  Award,
  TrendingUp,
  Download,
  Trash2,
  Search,
  Filter,
  Eye,
  AlertTriangle,
  FileSpreadsheet,
  RefreshCw,
  X,
  CheckCircle,
  HelpCircle,
  ChevronRight,
  Shield,
} from 'lucide-react';
import { AssessmentRecord, PerformanceLevel } from '../types/simulator';
import {
  clearAllAssessments,
  deleteClassAssessments,
  deleteStudentAssessment,
  exportAssessmentCSV,
  getStudentAssessments,
  restoreDefaultRecords,
} from '../services/storage';

interface TeacherDashboardProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ isOpen, onClose }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordError, setPasswordError] = useState('');

  // Records state
  const [records, setRecords] = useState<AssessmentRecord[]>([]);

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSection, setSelectedSection] = useState<string>('ALL');
  const [selectedLevel, setSelectedLevel] = useState<string>('ALL');

  // Active student modal for viewing full submission details
  const [viewingRecord, setViewingRecord] = useState<AssessmentRecord | null>(null);

  // Deletion modals state
  const [studentToDelete, setStudentToDelete] = useState<AssessmentRecord | null>(null);
  const [sectionToClear, setSectionToClear] = useState<string>('');
  const [showClearClassModal, setShowClearClassModal] = useState(false);
  const [showResetDbModal, setShowResetDbModal] = useState(false);

  // Notification toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Reload records from storage
  const refreshRecords = () => {
    setRecords(getStudentAssessments());
  };

  // Authenticate teacher
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === 'changemaker2026') {
      setIsAuthenticated(true);
      setPasswordError('');
      setPasswordInput('');
      setRecords(getStudentAssessments());
    } else {
      setPasswordError('Invalid teacher access password. Default is changemaker2026');
    }
  };

  // Unique sections for filtering
  const uniqueSections = useMemo(() => {
    const set = new Set<string>();
    records.forEach((r) => {
      if (r.section) set.add(r.section);
    });
    return Array.from(set).sort();
  }, [records]);

  // Filtered records
  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      const matchSearch =
        r.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (r.studentNumber && r.studentNumber.includes(searchQuery)) ||
        r.section.toLowerCase().includes(searchQuery.toLowerCase());

      const matchSection = selectedSection === 'ALL' || r.section === selectedSection;
      const matchLevel = selectedLevel === 'ALL' || r.scores.performanceLevel === selectedLevel;

      return matchSearch && matchSection && matchLevel;
    });
  }, [records, searchQuery, selectedSection, selectedLevel]);

  // Analytics Computations
  const analytics = useMemo(() => {
    const total = records.length;
    if (total === 0) {
      return {
        total: 0,
        averageScore: 0,
        averagePercentage: 0,
        highestScore: 0,
        lowestScore: 0,
        passingCount: 0,
        passingRate: 0,
        distribution: {
          Outstanding: 0,
          'Very Satisfactory': 0,
          Satisfactory: 0,
          'Fairly Satisfactory': 0,
          'Needs Improvement': 0,
        },
      };
    }

    const scores = records.map((r) => r.scores.total);
    const sum = scores.reduce((a, b) => a + b, 0);
    const avgScore = sum / total;
    const avgPct = records.reduce((a, b) => a + b.scores.percentage, 0) / total;
    const highest = Math.max(...scores);
    const lowest = Math.min(...scores);
    const passingCount = records.filter((r) => r.scores.percentage >= 75).length;
    const passingRate = (passingCount / total) * 100;

    const distribution: Record<PerformanceLevel, number> = {
      Outstanding: 0,
      'Very Satisfactory': 0,
      Satisfactory: 0,
      'Fairly Satisfactory': 0,
      'Needs Improvement': 0,
    };

    records.forEach((r) => {
      if (distribution[r.scores.performanceLevel] !== undefined) {
        distribution[r.scores.performanceLevel]++;
      }
    });

    return {
      total,
      averageScore: Math.round(avgScore * 10) / 10,
      averagePercentage: Math.round(avgPct),
      highestScore: Math.round(highest * 10) / 10,
      lowestScore: Math.round(lowest * 10) / 10,
      passingCount,
      passingRate: Math.round(passingRate),
      distribution,
    };
  }, [records]);

  // Actions
  const handleExportCSV = (excelCompatible: boolean) => {
    if (records.length === 0) {
      showToast('No student records available to export.');
      return;
    }
    exportAssessmentCSV(filteredRecords.length > 0 ? filteredRecords : records, excelCompatible);
    showToast(`Exported ${filteredRecords.length > 0 ? filteredRecords.length : records.length} records to assessment_results.csv`);
  };

  const confirmDeleteOneStudent = () => {
    if (studentToDelete) {
      deleteStudentAssessment(studentToDelete.id);
      refreshRecords();
      setStudentToDelete(null);
      showToast(`Student record for ${studentToDelete.studentName} deleted.`);
    }
  };

  const confirmClearClass = () => {
    if (sectionToClear) {
      deleteClassAssessments(sectionToClear);
      refreshRecords();
      setShowClearClassModal(false);
      setSectionToClear('');
      showToast(`All records for section "${sectionToClear}" cleared.`);
    }
  };

  const confirmResetDatabase = () => {
    clearAllAssessments();
    refreshRecords();
    setShowResetDbModal(false);
    showToast('Database reset complete. All student assessment records deleted.');
  };

  const handleRestoreDemo = () => {
    restoreDefaultRecords();
    refreshRecords();
    showToast('Restored default Senior High School assessment demo records.');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white rounded-2xl shadow-2xl max-w-6xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Toast */}
        {toastMessage && (
          <div className="absolute top-4 right-4 z-50 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-lg shadow-xl border border-slate-700 flex items-center space-x-2 animate-bounce">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Modal Top Bar */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold">
              <Shield className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-blue-300">
                Empowerment Technologies Teacher Admin
              </span>
              <h1 className="text-lg font-bold leading-tight">Teacher Assessment Dashboard</h1>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body content */}
        {!isAuthenticated ? (
          /* Password Authentication Gate */
          <div className="p-8 sm:p-12 text-center max-w-md mx-auto my-auto space-y-5">
            <div className="w-14 h-14 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center mx-auto">
              <Lock className="w-7 h-7" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900">Protected Teacher Portal</h2>
              <p className="text-xs text-slate-500 mt-1">
                Enter your administrative password to access student records, analytics, and CSV exports.
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <input
                  type="password"
                  value={passwordInput}
                  onChange={(e) => {
                    setPasswordInput(e.target.value);
                    if (passwordError) setPasswordError('');
                  }}
                  placeholder="Enter teacher password..."
                  className="w-full px-4 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-lg text-center tracking-widest focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900"
                />
                {passwordError && (
                  <p className="text-xs text-rose-600 mt-1 font-medium">{passwordError}</p>
                )}
                <p className="text-[11px] text-slate-400 mt-2">
                  Default Teacher Password: <code className="font-mono font-bold text-slate-700 bg-slate-100 px-1 py-0.5 rounded">changemaker2026</code>
                </p>
              </div>

              <div className="flex space-x-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="w-1/2 py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 px-4 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-lg transition-colors shadow-xs cursor-pointer"
                >
                  Unlock Dashboard
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* Authenticated Dashboard View */
          <div className="p-6 overflow-y-auto space-y-6">
            {/* Action Bar (Exports & Clears) */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wide">
                  Export Assessment Data:
                </span>
                <button
                  type="button"
                  onClick={() => handleExportCSV(false)}
                  className="px-3 py-1.5 bg-blue-700 hover:bg-blue-800 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5 shadow-2xs transition-colors cursor-pointer"
                  title="Download standard CSV file (assessment_results.csv)"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export CSV</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleExportCSV(true)}
                  className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5 shadow-2xs transition-colors cursor-pointer"
                  title="Download Excel-Compatible CSV with UTF-8 BOM"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  <span>Export Excel-Compatible</span>
                </button>
              </div>

              {/* Clear Options */}
              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={() => setShowClearClassModal(true)}
                  className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-colors cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5 text-amber-600" />
                  <span>Clear Class Section</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowResetDbModal(true)}
                  className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-colors cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                  <span>Reset Entire Database</span>
                </button>
                {records.length === 0 && (
                  <button
                    type="button"
                    onClick={handleRestoreDemo}
                    className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Restore Demo Records</span>
                  </button>
                )}
              </div>
            </div>

            {/* Analytics Stats Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Total Assessed
                </span>
                <div className="flex items-baseline space-x-1 mt-1">
                  <span className="text-2xl font-extrabold text-slate-900 font-mono">
                    {analytics.total}
                  </span>
                  <span className="text-xs text-slate-400">students</span>
                </div>
              </div>

              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Class Average
                </span>
                <div className="flex items-baseline space-x-1 mt-1">
                  <span className="text-2xl font-extrabold text-blue-700 font-mono">
                    {analytics.averageScore}
                  </span>
                  <span className="text-xs text-slate-400">/ 100 ({analytics.averagePercentage}%)</span>
                </div>
              </div>

              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Highest Score
                </span>
                <div className="flex items-baseline space-x-1 mt-1">
                  <span className="text-2xl font-extrabold text-emerald-600 font-mono">
                    {analytics.highestScore}
                  </span>
                  <span className="text-xs text-slate-400">pts</span>
                </div>
              </div>

              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Lowest Score
                </span>
                <div className="flex items-baseline space-x-1 mt-1">
                  <span className="text-2xl font-extrabold text-amber-600 font-mono">
                    {analytics.lowestScore}
                  </span>
                  <span className="text-xs text-slate-400">pts</span>
                </div>
              </div>
            </div>

            {/* Score Distribution Chart */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Performance Level Distribution
                </h3>
                <span className="text-xs font-semibold text-emerald-700">
                  Passing Rate (≥75%): {analytics.passingRate}% ({analytics.passingCount}/{analytics.total})
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                <div className="bg-emerald-50/70 border border-emerald-200 p-3 rounded-lg text-center">
                  <span className="text-[10px] font-bold text-emerald-800 block uppercase">
                    Outstanding (90-100)
                  </span>
                  <span className="text-xl font-extrabold text-emerald-700 font-mono">
                    {analytics.distribution.Outstanding}
                  </span>
                </div>

                <div className="bg-blue-50/70 border border-blue-200 p-3 rounded-lg text-center">
                  <span className="text-[10px] font-bold text-blue-800 block uppercase">
                    Very Satisfactory (85-89)
                  </span>
                  <span className="text-xl font-extrabold text-blue-700 font-mono">
                    {analytics.distribution['Very Satisfactory']}
                  </span>
                </div>

                <div className="bg-teal-50/70 border border-teal-200 p-3 rounded-lg text-center">
                  <span className="text-[10px] font-bold text-teal-800 block uppercase">
                    Satisfactory (80-84)
                  </span>
                  <span className="text-xl font-extrabold text-teal-700 font-mono">
                    {analytics.distribution.Satisfactory}
                  </span>
                </div>

                <div className="bg-amber-50/70 border border-amber-200 p-3 rounded-lg text-center">
                  <span className="text-[10px] font-bold text-amber-800 block uppercase">
                    Fairly Satisfactory (75-79)
                  </span>
                  <span className="text-xl font-extrabold text-amber-700 font-mono">
                    {analytics.distribution['Fairly Satisfactory']}
                  </span>
                </div>

                <div className="bg-rose-50/70 border border-rose-200 p-3 rounded-lg text-center col-span-2 sm:col-span-1">
                  <span className="text-[10px] font-bold text-rose-800 block uppercase">
                    Needs Improvement (&lt;75)
                  </span>
                  <span className="text-xl font-extrabold text-rose-700 font-mono">
                    {analytics.distribution['Needs Improvement']}
                  </span>
                </div>
              </div>
            </div>

            {/* Filter and Search Bar */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
              {/* Search */}
              <div className="relative flex-1 min-w-[200px]">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search student name, section, or student number..."
                  className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900"
                />
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              </div>

              {/* Section Filter */}
              <div className="flex items-center space-x-2">
                <span className="text-xs text-slate-500 font-medium">Section:</span>
                <select
                  value={selectedSection}
                  onChange={(e) => setSelectedSection(e.target.value)}
                  className="text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-600"
                >
                  <option value="ALL">All Sections ({uniqueSections.length})</option>
                  {uniqueSections.map((sec) => (
                    <option key={sec} value={sec}>
                      {sec}
                    </option>
                  ))}
                </select>
              </div>

              {/* Level Filter */}
              <div className="flex items-center space-x-2">
                <span className="text-xs text-slate-500 font-medium">Level:</span>
                <select
                  value={selectedLevel}
                  onChange={(e) => setSelectedLevel(e.target.value)}
                  className="text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-600"
                >
                  <option value="ALL">All Levels</option>
                  <option value="Outstanding">Outstanding (90-100)</option>
                  <option value="Very Satisfactory">Very Satisfactory (85-89)</option>
                  <option value="Satisfactory">Satisfactory (80-84)</option>
                  <option value="Fairly Satisfactory">Fairly Satisfactory (75-79)</option>
                  <option value="Needs Improvement">Needs Improvement (&lt;75)</option>
                </select>
              </div>
            </div>

            {/* Records Table */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-100 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                    <tr>
                      <th className="px-4 py-3">Student Name</th>
                      <th className="px-3 py-3">Section</th>
                      <th className="px-3 py-3">Date</th>
                      <th className="px-2 py-3 text-center" title="Phase 1: Problem Analysis (Max 15)">P1</th>
                      <th className="px-2 py-3 text-center" title="Phase 2: Research Skills (Max 20)">P2</th>
                      <th className="px-2 py-3 text-center" title="Phase 3: ICT Solution (Max 20)">P3</th>
                      <th className="px-2 py-3 text-center" title="Phase 4: Content Creation (Max 15)">P4</th>
                      <th className="px-2 py-3 text-center" title="Phase 5: Digital Ethics (Max 20)">P5</th>
                      <th className="px-2 py-3 text-center" title="Phase 6: Reflection (Max 10)">P6</th>
                      <th className="px-3 py-3 text-center">Score</th>
                      <th className="px-3 py-3 text-center">Pct</th>
                      <th className="px-3 py-3">Performance Level</th>
                      <th className="px-4 py-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-800">
                    {filteredRecords.length === 0 ? (
                      <tr>
                        <td colSpan={13} className="px-4 py-8 text-center text-slate-400">
                          No student assessment records found matching your filters.
                        </td>
                      </tr>
                    ) : (
                      filteredRecords.map((r) => (
                        <tr key={r.id} className="hover:bg-slate-50/70 transition-colors">
                          <td className="px-4 py-3">
                            <span className="font-bold text-slate-900 block">{r.studentName}</span>
                            {r.studentNumber && (
                              <span className="text-[10px] text-slate-400 font-mono">
                                LRN: {r.studentNumber}
                              </span>
                            )}
                          </td>
                          <td className="px-3 py-3 text-slate-600 font-medium">{r.section}</td>
                          <td className="px-3 py-3 text-slate-500 font-mono text-[11px]">
                            {r.completedAt || new Date(r.timestamp).toLocaleDateString()}
                          </td>
                          <td className="px-2 py-3 text-center font-mono text-slate-600">
                            {r.scores.problemAnalysis.toFixed(1)}
                          </td>
                          <td className="px-2 py-3 text-center font-mono text-slate-600">
                            {r.scores.researchSkills.toFixed(1)}
                          </td>
                          <td className="px-2 py-3 text-center font-mono text-slate-600">
                            {r.scores.solutionDesign.toFixed(1)}
                          </td>
                          <td className="px-2 py-3 text-center font-mono text-slate-600">
                            {r.scores.contentCreation.toFixed(1)}
                          </td>
                          <td className="px-2 py-3 text-center font-mono text-slate-600">
                            {r.scores.ethics.toFixed(1)}
                          </td>
                          <td className="px-2 py-3 text-center font-mono text-slate-600">
                            {r.scores.reflection.toFixed(1)}
                          </td>
                          <td className="px-3 py-3 text-center font-bold text-blue-700 font-mono text-sm">
                            {r.scores.total.toFixed(1)}
                          </td>
                          <td className="px-3 py-3 text-center font-bold font-mono text-slate-800">
                            {r.scores.percentage}%
                          </td>
                          <td className="px-3 py-3">
                            <span
                              className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                                r.scores.performanceLevel === 'Outstanding'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : r.scores.performanceLevel === 'Very Satisfactory'
                                  ? 'bg-blue-100 text-blue-800'
                                  : r.scores.performanceLevel === 'Satisfactory'
                                  ? 'bg-teal-100 text-teal-800'
                                  : r.scores.performanceLevel === 'Fairly Satisfactory'
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {r.scores.performanceLevel}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right space-x-1.5 whitespace-nowrap">
                            <button
                              type="button"
                              onClick={() => setViewingRecord(r)}
                              className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[11px] font-semibold inline-flex items-center space-x-1 cursor-pointer"
                              title="View full student responses and AI assessment remarks"
                            >
                              <Eye className="w-3 h-3" />
                              <span>View</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setStudentToDelete(r)}
                              className="p-1 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded transition-colors cursor-pointer"
                              title="Delete this student record"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="bg-slate-100 px-6 py-3 border-t border-slate-200 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-slate-500">
            {isAuthenticated
              ? `Showing ${filteredRecords.length} of ${records.length} total assessment records.`
              : 'Empowerment Technologies • K-12 DepEd Senior High School Assessment'}
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
          >
            Close Dashboard
          </button>
        </div>
      </div>

      {/* MODAL: View Student Submission Details */}
      {viewingRecord && (
        <div className="fixed inset-0 z-60 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[88vh]">
            <div className="bg-blue-900 text-white px-6 py-4 flex items-center justify-between">
              <div>
                <span className="text-xs uppercase text-blue-200 font-semibold">
                  Student Submission Portfolio
                </span>
                <h2 className="text-base font-bold">{viewingRecord.studentName}</h2>
                <p className="text-xs text-blue-100">
                  {viewingRecord.section} • Score: {viewingRecord.scores.total} ({viewingRecord.scores.percentage}%) • {viewingRecord.scores.performanceLevel}
                </p>
              </div>
              <button
                onClick={() => setViewingRecord(null)}
                className="text-blue-200 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 text-xs text-slate-800">
              {/* AI Facilitator Remarks */}
              <div className="bg-blue-50 border border-blue-200 p-4 rounded-xl space-y-1">
                <span className="font-bold text-blue-900 block">AI Assessment Facilitator & Community Adviser Notes:</span>
                <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">
                  {viewingRecord.aiFeedback || 'Evaluation completed according to DepEd rubric.'}
                </p>
              </div>

              {/* Phase 1 */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                <span className="font-bold text-slate-900 text-sm block">
                  Phase 1: Problem Analysis ({viewingRecord.scores.problemAnalysis} / 15 pts)
                </span>
                <p><strong>Main Issue:</strong> {viewingRecord.responses.phase1.mainIssue}</p>
                <p><strong>Stakeholders:</strong> {viewingRecord.responses.phase1.stakeholders}</p>
                <p><strong>Consequences if Unresolved:</strong> {viewingRecord.responses.phase1.consequences}</p>
              </div>

              {/* Phase 2 */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                <span className="font-bold text-slate-900 text-sm block">
                  Phase 2: Research Skills ({viewingRecord.scores.researchSkills} / 20 pts)
                </span>
                <p><strong>Verification Strategy:</strong> {viewingRecord.responses.phase2.verificationMethods}</p>
              </div>

              {/* Phase 3 */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                <span className="font-bold text-slate-900 text-sm block">
                  Phase 3: ICT Solution Design ({viewingRecord.scores.solutionDesign} / 20 pts)
                </span>
                <p><strong>Platform:</strong> {viewingRecord.responses.phase3.platform}</p>
                <p><strong>Justification:</strong> {viewingRecord.responses.phase3.justification}</p>
                <p><strong>Target Audience:</strong> {viewingRecord.responses.phase3.audience}</p>
                <p><strong>Outcomes:</strong> {viewingRecord.responses.phase3.outcomes}</p>
              </div>

              {/* Phase 4 */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                <span className="font-bold text-slate-900 text-sm block">
                  Phase 4: Content Creation ({viewingRecord.scores.contentCreation} / 15 pts)
                </span>
                <p><strong>Slogan:</strong> "{viewingRecord.responses.phase4.slogan}"</p>
                <p><strong>Post:</strong> {viewingRecord.responses.phase4.post}</p>
                <p><strong>CTA:</strong> {viewingRecord.responses.phase4.cta}</p>
                <p><strong>Hashtags:</strong> {viewingRecord.responses.phase4.hashtags}</p>
                <p><strong>Infographic Caption:</strong> {viewingRecord.responses.phase4.caption}</p>
              </div>

              {/* Phase 6 */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                <span className="font-bold text-slate-900 text-sm block">
                  Phase 6: Reflection ({viewingRecord.scores.reflection} / 10 pts)
                </span>
                <p className="whitespace-pre-line leading-relaxed">{viewingRecord.responses.phase6.essay}</p>
              </div>
            </div>

            <div className="bg-slate-100 px-6 py-3 border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={() => setViewingRecord(null)}
                className="px-4 py-2 bg-slate-800 text-white rounded-lg text-xs font-semibold"
              >
                Done Reviewing
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRMATION MODAL: Delete Single Student */}
      {studentToDelete && (
        <div className="fixed inset-0 z-70 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 p-6 space-y-4">
            <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Delete Student Assessment Record?</h3>
              <p className="text-xs text-slate-500 mt-1">
                Are you sure you want to delete the record for <strong>{studentToDelete.studentName}</strong> ({studentToDelete.section})? This action cannot be undone.
              </p>
            </div>
            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setStudentToDelete(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDeleteOneStudent}
                className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-2xs"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRMATION MODAL: Clear Current Class */}
      {showClearClassModal && (
        <div className="fixed inset-0 z-70 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 p-6 space-y-4">
            <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Clear Records for a Class Section</h3>
              <p className="text-xs text-slate-500 mt-1">
                Select the section whose assessment records you wish to completely remove.
              </p>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Select Section to Clear:</label>
              <select
                value={sectionToClear}
                onChange={(e) => setSectionToClear(e.target.value)}
                className="w-full text-xs p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
              >
                <option value="">-- Choose Section --</option>
                {uniqueSections.map((sec) => (
                  <option key={sec} value={sec}>
                    {sec}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowClearClassModal(false);
                  setSectionToClear('');
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={!sectionToClear}
                onClick={confirmClearClass}
                className={`px-4 py-2 text-xs font-bold rounded-lg shadow-2xs ${
                  sectionToClear
                    ? 'bg-amber-600 hover:bg-amber-700 text-white cursor-pointer'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                Clear Selected Section
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRMATION MODAL: Reset Entire Database */}
      {showResetDbModal && (
        <div className="fixed inset-0 z-70 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-rose-300 p-6 space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 text-rose-700">
                Warning: Reset Entire Database?
              </h3>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                This will delete <strong>ALL student assessment records</strong> from local storage. Make sure you have exported your CSV file first if you need an official archive.
              </p>
            </div>
            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setShowResetDbModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmResetDatabase}
                className="px-4 py-2 text-xs font-bold text-white bg-rose-700 hover:bg-rose-800 rounded-lg shadow-xs"
              >
                Permanently Delete All Records
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
