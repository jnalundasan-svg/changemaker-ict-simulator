import React, { useRef } from 'react';
import {
  Award,
  CheckCircle2,
  Printer,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  TrendingUp,
  FileText,
  Calendar,
  User,
  GraduationCap,
  Layers,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { AssessmentRecord, PerformanceLevel, ScoreBreakdown } from '../types/simulator';

interface CertificateResultsProps {
  record: AssessmentRecord;
  onRestart: () => void;
  onOpenTeacher: () => void;
}

export const CertificateResults: React.FC<CertificateResultsProps> = ({
  record,
  onRestart,
  onOpenTeacher,
}) => {
  const [showFullResponses, setShowFullResponses] = React.useState(false);
  const certificateRef = useRef<HTMLDivElement>(null);

  const { scores, studentName, section, studentNumber, completedAt, scenarioTitle, responses, aiFeedback } =
    record;

  const handlePrint = () => {
    window.print();
  };

  const getLevelBadge = (level: PerformanceLevel) => {
    switch (level) {
      case 'Outstanding':
        return {
          bg: 'bg-emerald-100 text-emerald-900 border-emerald-300',
          desc: 'Demonstrated exemplary mastery of ICT advocacy, critical research, and digital ethics.',
          color: 'text-emerald-700',
        };
      case 'Very Satisfactory':
        return {
          bg: 'bg-blue-100 text-blue-900 border-blue-300',
          desc: 'Exceeded standard competencies with strong analytical design and responsible digital participation.',
          color: 'text-blue-700',
        };
      case 'Satisfactory':
        return {
          bg: 'bg-teal-100 text-teal-900 border-teal-300',
          desc: 'Met core Empowerment Technologies competencies and established sound civic ICT planning.',
          color: 'text-teal-700',
        };
      case 'Fairly Satisfactory':
        return {
          bg: 'bg-amber-100 text-amber-900 border-amber-300',
          desc: 'Demonstrated fundamental understanding; further enrichment needed in digital verification and ethics.',
          color: 'text-amber-700',
        };
      case 'Needs Improvement':
      default:
        return {
          bg: 'bg-rose-100 text-rose-900 border-rose-300',
          desc: 'Requires focused remediation in research verification, digital citizenship, and audience profiling.',
          color: 'text-rose-700',
        };
    }
  };

  const levelInfo = getLevelBadge(scores.performanceLevel);

  return (
    <div className="max-w-4xl mx-auto py-8 px-4 sm:px-6 space-y-8 print:p-0 print:m-0">
      {/* Top Banner (Hidden in print) */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6 print:hidden">
        <div>
          <div className="inline-flex items-center space-x-2 bg-emerald-500/20 text-emerald-300 px-3 py-1 rounded-full text-xs font-semibold mb-3 border border-emerald-500/30">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Official Assessment Completed & Computed</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Simulation Assessment Report
          </h1>
          <p className="text-blue-200 text-xs sm:text-sm mt-1 max-w-xl">
            Congratulations, <strong className="text-white">{studentName}</strong>! Your advocacy project has been evaluated according to DepEd Senior High School Empowerment Technologies standards.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={handlePrint}
            className="px-4 py-2.5 bg-white hover:bg-slate-100 text-slate-800 rounded-xl font-bold text-xs flex items-center space-x-2 shadow-xs transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4 text-slate-600" />
            <span>Print Official Certificate</span>
          </button>
          <button
            type="button"
            onClick={onRestart}
            className="px-4 py-2.5 bg-blue-700 hover:bg-blue-600 text-white rounded-xl font-bold text-xs flex items-center space-x-2 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>New Student Assessment</span>
          </button>
        </div>
      </div>

      {/* Summary Score Cards (Hidden in print) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 print:hidden">
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">
            Total Raw Score
          </span>
          <div className="flex items-baseline space-x-2">
            <span className="text-4xl font-extrabold text-blue-700 font-mono">
              {scores.total.toFixed(1)}
            </span>
            <span className="text-sm font-bold text-slate-400">/ 100</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2">Comprehensive 6-phase evaluation</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">
            Percentage Rating
          </span>
          <div className="flex items-baseline space-x-2">
            <span className="text-4xl font-extrabold text-emerald-600 font-mono">
              {scores.percentage}%
            </span>
            <span className="text-xs text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded">
              DepEd SF9 Equivalent
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2">Authentic rubric performance index</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">
            Performance Level
          </span>
          <div className="inline-block mt-0.5">
            <span
              className={`text-lg font-black px-3 py-1 rounded-lg border ${levelInfo.bg}`}
            >
              {scores.performanceLevel}
            </span>
          </div>
          <p className="text-[11px] text-slate-600 mt-2 leading-tight">{levelInfo.desc}</p>
        </div>
      </div>

      {/* Printable Certificate Frame */}
      <div
        ref={certificateRef}
        className="bg-white rounded-2xl border-4 border-blue-900 p-8 sm:p-12 shadow-2xl relative overflow-hidden print:border-4 print:shadow-none print:m-0 print:p-8"
      >
        {/* Subtle decorative inner border */}
        <div className="border border-amber-600/40 p-6 sm:p-8 rounded-xl relative">
          {/* Watermark / Seal Icon */}
          <div className="absolute right-4 bottom-4 opacity-5 pointer-events-none">
            <GraduationCap className="w-80 h-80 text-blue-950" />
          </div>

          {/* Certificate Header */}
          <div className="text-center space-y-2 mb-8">
            <div className="flex items-center justify-center space-x-2 text-xs font-extrabold text-blue-800 tracking-widest uppercase">
              <ShieldCheck className="w-5 h-5 text-emerald-600" />
              <span>Republic of the Philippines • Senior High School</span>
            </div>
            <p className="text-[11px] text-slate-500 uppercase tracking-wider">
              Department of Education • Empowerment Technologies
            </p>
            <h2 className="text-2xl sm:text-4xl font-black text-slate-900 tracking-tight font-serif pt-2">
              Certificate of Social Impact & Digital Citizenship
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-700 to-emerald-500 mx-auto rounded-full mt-2" />
          </div>

          {/* Certificate Body */}
          <div className="text-center space-y-4 my-8 max-w-2xl mx-auto">
            <p className="text-xs text-slate-500 italic">This certifies that</p>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-blue-950 tracking-tight underline decoration-amber-500 decoration-2 underline-offset-8">
              {studentName}
            </h3>
            <p className="text-xs font-semibold text-slate-600">
              {section} {studentNumber ? `• Student No: ${studentNumber}` : ''}
            </p>

            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed pt-2">
              has satisfactorily completed the authentic assessment simulation on{' '}
              <strong className="text-slate-900">ICT as a Platform for Social Change</strong>,
              demonstrating mastery of digital citizenship, media literacy, information evaluation,
              content creation, and online safety for the advocacy project:
            </p>

            <div className="bg-blue-50/70 border border-blue-200 py-2.5 px-4 rounded-lg inline-block text-xs sm:text-sm font-bold text-blue-900">
              "{scenarioTitle}"
            </div>

            <div className="pt-4 flex items-center justify-center space-x-6 text-xs text-slate-800">
              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Final Raw Score</span>
                <span className="font-bold text-base text-blue-800 font-mono">
                  {scores.total.toFixed(1)} / 100
                </span>
              </div>
              <div className="h-8 w-px bg-slate-300" />
              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Percentage</span>
                <span className="font-bold text-base text-emerald-700 font-mono">
                  {scores.percentage}%
                </span>
              </div>
              <div className="h-8 w-px bg-slate-300" />
              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Rating</span>
                <span className="font-bold text-base text-slate-900">
                  {scores.performanceLevel}
                </span>
              </div>
            </div>
          </div>

          {/* Signatures & Date */}
          <div className="grid grid-cols-2 gap-8 pt-8 mt-8 border-t border-slate-200 text-center text-xs">
            <div>
              <div className="w-48 mx-auto border-b border-slate-400 mb-1.5 pt-6 font-script text-slate-800 text-sm italic">
                ChangeMaker Assessment Engine
              </div>
              <p className="font-bold text-slate-800">Empowerment Technologies Facilitator</p>
              <p className="text-[10px] text-slate-400">ICT & Advocacy Department</p>
            </div>

            <div>
              <div className="w-48 mx-auto border-b border-slate-400 mb-1.5 pt-6 font-mono text-slate-700 text-xs">
                {completedAt}
              </div>
              <p className="font-bold text-slate-800">Date Issued</p>
              <p className="text-[10px] text-slate-400">Official Assessment Record</p>
            </div>
          </div>
        </div>
      </div>

      {/* AI Facilitator Feedback & Community Adviser Notes */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-3 print:hidden">
        <div className="flex items-center space-x-2 text-blue-800">
          <Sparkles className="w-5 h-5 text-emerald-600" />
          <h2 className="text-base font-bold text-slate-900">
            AI Community Adviser & Assessment Facilitator Evaluation
          </h2>
        </div>
        <p className="text-xs text-slate-500">
          Personalized qualitative feedback generated for your exact project decisions and advocacy synthesis:
        </p>

        <div className="bg-slate-50 p-4.5 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-800 leading-relaxed whitespace-pre-line">
          {aiFeedback ||
            'Your submission demonstrates commendable critical thinking, authentic audience analysis, and clear alignment with DepEd Empowerment Technologies competencies.'}
        </div>
      </div>

      {/* Detailed Criterion Breakdown Table */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4 print:hidden">
        <h2 className="text-base font-bold text-slate-900 flex items-center space-x-2">
          <Layers className="w-5 h-5 text-blue-700" />
          <span>Competency-Based Criterion Breakdown</span>
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="px-4 py-3 rounded-l-lg">Phase & Competency Area</th>
                <th className="px-3 py-3">Core Criteria</th>
                <th className="px-3 py-3 text-center">Score</th>
                <th className="px-3 py-3 text-center">Max</th>
                <th className="px-4 py-3 rounded-r-lg text-right">Performance Ratio</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              <tr>
                <td className="px-4 py-3 font-semibold text-slate-900">1. Problem Analysis</td>
                <td className="px-3 py-3 text-slate-500">Accuracy, Social Impact, Critical Thinking</td>
                <td className="px-3 py-3 text-center font-bold font-mono">{scores.problemAnalysis.toFixed(1)}</td>
                <td className="px-3 py-3 text-center text-slate-400">15</td>
                <td className="px-4 py-3 text-right">
                  <div className="w-24 bg-slate-100 h-2 rounded-full inline-block overflow-hidden align-middle ml-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${(scores.problemAnalysis / 15) * 100}%` }}
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <td className="px-4 py-3 font-semibold text-slate-900">2. Online Research Skills</td>
                <td className="px-3 py-3 text-slate-500">Source Evaluation, Critical Analysis, Verification</td>
                <td className="px-3 py-3 text-center font-bold font-mono">{scores.researchSkills.toFixed(1)}</td>
                <td className="px-3 py-3 text-center text-slate-400">20</td>
                <td className="px-4 py-3 text-right">
                  <div className="w-24 bg-slate-100 h-2 rounded-full inline-block overflow-hidden align-middle ml-2">
                    <div
                      className="bg-emerald-600 h-2 rounded-full"
                      style={{ width: `${(scores.researchSkills / 20) * 100}%` }}
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <td className="px-4 py-3 font-semibold text-slate-900">3. ICT Solution Design</td>
                <td className="px-3 py-3 text-slate-500">Relevance, Audience Profiling, Feasibility</td>
                <td className="px-3 py-3 text-center font-bold font-mono">{scores.solutionDesign.toFixed(1)}</td>
                <td className="px-3 py-3 text-center text-slate-400">20</td>
                <td className="px-4 py-3 text-right">
                  <div className="w-24 bg-slate-100 h-2 rounded-full inline-block overflow-hidden align-middle ml-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${(scores.solutionDesign / 20) * 100}%` }}
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <td className="px-4 py-3 font-semibold text-slate-900">4. Content Creation Challenge</td>
                <td className="px-3 py-3 text-slate-500">Persuasiveness, Creativity, Clarity, Audience Fit</td>
                <td className="px-3 py-3 text-center font-bold font-mono">{scores.contentCreation.toFixed(1)}</td>
                <td className="px-3 py-3 text-center text-slate-400">15</td>
                <td className="px-4 py-3 text-right">
                  <div className="w-24 bg-slate-100 h-2 rounded-full inline-block overflow-hidden align-middle ml-2">
                    <div
                      className="bg-emerald-600 h-2 rounded-full"
                      style={{ width: `${(scores.contentCreation / 15) * 100}%` }}
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <td className="px-4 py-3 font-semibold text-slate-900">5. Digital Ethics Simulation</td>
                <td className="px-3 py-3 text-slate-500">Online Ethics, Safety, Digital Citizenship</td>
                <td className="px-3 py-3 text-center font-bold font-mono">{scores.ethics.toFixed(1)}</td>
                <td className="px-3 py-3 text-center text-slate-400">20</td>
                <td className="px-4 py-3 text-right">
                  <div className="w-24 bg-slate-100 h-2 rounded-full inline-block overflow-hidden align-middle ml-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${(scores.ethics / 20) * 100}%` }}
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <td className="px-4 py-3 font-semibold text-slate-900">6. Reflection Essay</td>
                <td className="px-3 py-3 text-slate-500">Insight, Understanding, Personal Relevance</td>
                <td className="px-3 py-3 text-center font-bold font-mono">{scores.reflection.toFixed(1)}</td>
                <td className="px-3 py-3 text-center text-slate-400">10</td>
                <td className="px-4 py-3 text-right">
                  <div className="w-24 bg-slate-100 h-2 rounded-full inline-block overflow-hidden align-middle ml-2">
                    <div
                      className="bg-emerald-600 h-2 rounded-full"
                      style={{ width: `${(scores.reflection / 10) * 100}%` }}
                    />
                  </div>
                </td>
              </tr>
            </tbody>
            <tfoot className="border-t-2 border-slate-300 font-bold bg-slate-50">
              <tr>
                <td colSpan={2} className="px-4 py-3 text-slate-900">
                  Total Assessment Score
                </td>
                <td className="px-3 py-3 text-center font-mono text-blue-700 text-sm">
                  {scores.total.toFixed(1)}
                </td>
                <td className="px-3 py-3 text-center text-slate-600 text-sm">100</td>
                <td className="px-4 py-3 text-right text-emerald-700 font-mono text-sm">
                  {scores.percentage}% ({scores.performanceLevel})
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Toggle View Full Submitted Responses */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3 print:hidden">
        <button
          type="button"
          onClick={() => setShowFullResponses(!showFullResponses)}
          className="w-full flex items-center justify-between text-xs font-bold text-slate-700 hover:text-slate-900 cursor-pointer"
        >
          <span className="flex items-center space-x-2">
            <FileText className="w-4 h-4 text-blue-600" />
            <span>Review Full Student Submission Portfolio</span>
          </span>
          {showFullResponses ? (
            <ChevronUp className="w-4 h-4 text-slate-500" />
          ) : (
            <ChevronDown className="w-4 h-4 text-slate-500" />
          )}
        </button>

        {showFullResponses && (
          <div className="pt-4 border-t border-slate-100 space-y-4 text-xs text-slate-700">
            {/* Phase 1 */}
            <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200 space-y-1.5">
              <span className="font-bold text-blue-900 block">Phase 1: Problem Analysis</span>
              <p><strong>Main Issue:</strong> {responses.phase1.mainIssue}</p>
              <p><strong>Stakeholders:</strong> {responses.phase1.stakeholders}</p>
              <p><strong>Consequences:</strong> {responses.phase1.consequences}</p>
            </div>

            {/* Phase 3 */}
            <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200 space-y-1.5">
              <span className="font-bold text-blue-900 block">Phase 3: ICT Solution Design</span>
              <p><strong>Platform:</strong> {responses.phase3.platform}</p>
              <p><strong>Justification:</strong> {responses.phase3.justification}</p>
              <p><strong>Target Audience:</strong> {responses.phase3.audience}</p>
              <p><strong>Expected Outcomes:</strong> {responses.phase3.outcomes}</p>
            </div>

            {/* Phase 4 */}
            <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200 space-y-1.5">
              <span className="font-bold text-blue-900 block">Phase 4: Content Creation</span>
              <p><strong>Slogan:</strong> "{responses.phase4.slogan}"</p>
              <p><strong>Post:</strong> {responses.phase4.post}</p>
              <p><strong>CTA:</strong> {responses.phase4.cta}</p>
              <p><strong>Hashtags:</strong> {responses.phase4.hashtags}</p>
              <p><strong>Caption:</strong> {responses.phase4.caption}</p>
            </div>

            {/* Phase 6 */}
            <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200 space-y-1.5">
              <span className="font-bold text-blue-900 block">Phase 6: Reflection Essay</span>
              <p className="whitespace-pre-line leading-relaxed">{responses.phase6.essay}</p>
            </div>
          </div>
        )}
      </div>

      {/* Bottom actions */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 print:hidden">
        <p className="text-xs text-slate-400">
          Permanent Record ID: <span className="font-mono">{record.id}</span>
        </p>
        <div className="flex items-center space-x-3">
          <button
            type="button"
            onClick={onOpenTeacher}
            className="text-xs font-semibold text-slate-600 hover:text-slate-900 px-3 py-2 rounded-lg hover:bg-slate-100 transition-colors"
          >
            Access Teacher Records
          </button>
          <button
            type="button"
            onClick={onRestart}
            className="px-5 py-2.5 bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            Start New Assessment Session
          </button>
        </div>
      </div>
    </div>
  );
};
