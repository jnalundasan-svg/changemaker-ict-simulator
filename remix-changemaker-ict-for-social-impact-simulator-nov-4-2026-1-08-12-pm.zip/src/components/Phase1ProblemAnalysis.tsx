import React from 'react';
import { HelpCircle, Users, AlertTriangle, ArrowRight, BookOpen } from 'lucide-react';
import { Phase1Response, ScenarioData } from '../types/simulator';

interface Phase1ProblemAnalysisProps {
  scenario: ScenarioData;
  data: Phase1Response;
  onChange: (updated: Phase1Response) => void;
  onNext: () => void;
  onOpenBrief: () => void;
}

export const Phase1ProblemAnalysis: React.FC<Phase1ProblemAnalysisProps> = ({
  scenario,
  data,
  onChange,
  onNext,
  onOpenBrief,
}) => {
  const isFormValid =
    data.mainIssue.trim().length >= 10 &&
    data.stakeholders.trim().length >= 10 &&
    data.consequences.trim().length >= 10;

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 sm:px-6 space-y-6">
      {/* Phase Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-bold text-blue-700 uppercase tracking-wider mb-1">
            <span>Phase 1 of 6</span>
            <span>•</span>
            <span>Competency: ICT as a Platform for Change</span>
          </div>
          <h1 className="text-xl font-extrabold text-slate-900">Problem Analysis</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Demonstrate your ability to diagnose community challenges, identify human stakeholders, and assess social impact.
          </p>
        </div>
        <div className="flex items-center space-x-2 shrink-0">
          <button
            type="button"
            onClick={onOpenBrief}
            className="inline-flex items-center space-x-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors"
          >
            <BookOpen className="w-4 h-4 text-blue-600" />
            <span>Read Full Scenario Brief</span>
          </button>
          <div className="bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-bold text-slate-700">
            Max 15 Pts
          </div>
        </div>
      </div>

      {/* Scenario Snapshot card */}
      <div className="bg-blue-50/80 border border-blue-200 rounded-xl p-4.5">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-blue-900 uppercase tracking-wide">
            Assigned Community Issue: {scenario.category}
          </span>
          <span className="text-xs text-blue-700 font-medium">{scenario.location}</span>
        </div>
        <p className="text-xs text-slate-700 line-clamp-3 leading-relaxed">
          {scenario.narrative}
        </p>
      </div>

      {/* Questions Form */}
      <div className="space-y-6 bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        {/* Question 1 */}
        <div className="space-y-2">
          <div className="flex items-start justify-between">
            <label className="text-sm font-bold text-slate-900 flex items-center space-x-2">
              <span className="w-6 h-6 rounded-full bg-blue-700 text-white text-xs flex items-center justify-center shrink-0">
                1
              </span>
              <span>What is the main issue?</span>
            </label>
            <span className="text-[11px] text-slate-400 font-medium">Criterion: Accuracy (5 pts)</span>
          </div>
          <p className="text-xs text-slate-500 pl-8">
            Clearly define the core problem affecting the community. What specific behavior, condition, or digital gap is causing harm?
          </p>
          <div className="pl-8">
            <textarea
              rows={4}
              value={data.mainIssue}
              onChange={(e) => onChange({ ...data, mainIssue: e.target.value })}
              placeholder="Explain the central issue with specific reference to the localized scenario..."
              className="w-full p-3.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900 leading-relaxed"
            />
            <div className="flex justify-between items-center text-[11px] text-slate-400 mt-1">
              <span>Aim for clarity and precise identification of root causes.</span>
              <span>{data.mainIssue.trim().length} characters</span>
            </div>
          </div>
        </div>

        {/* Question 2 */}
        <div className="space-y-2 pt-4 border-t border-slate-100">
          <div className="flex items-start justify-between">
            <label className="text-sm font-bold text-slate-900 flex items-center space-x-2">
              <span className="w-6 h-6 rounded-full bg-blue-700 text-white text-xs flex items-center justify-center shrink-0">
                2
              </span>
              <span>Who are the stakeholders?</span>
            </label>
            <span className="text-[11px] text-slate-400 font-medium">Criterion: Awareness of Social Impact (5 pts)</span>
          </div>
          <p className="text-xs text-slate-500 pl-8">
            Identify the key individuals, groups, or institutions directly or indirectly affected by this problem (e.g. victims, youth, leaders, community members).
          </p>
          <div className="pl-8">
            <textarea
              rows={4}
              value={data.stakeholders}
              onChange={(e) => onChange({ ...data, stakeholders: e.target.value })}
              placeholder="Enumerate the primary and secondary stakeholders and their roles in this community issue..."
              className="w-full p-3.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900 leading-relaxed"
            />
            <div className="flex justify-between items-center text-[11px] text-slate-400 mt-1">
              <span>Consider both vulnerable groups and institutional decision-makers.</span>
              <span>{data.stakeholders.trim().length} characters</span>
            </div>
          </div>
        </div>

        {/* Question 3 */}
        <div className="space-y-2 pt-4 border-t border-slate-100">
          <div className="flex items-start justify-between">
            <label className="text-sm font-bold text-slate-900 flex items-center space-x-2">
              <span className="w-6 h-6 rounded-full bg-blue-700 text-white text-xs flex items-center justify-center shrink-0">
                3
              </span>
              <span>What could happen if the problem remains unresolved?</span>
            </label>
            <span className="text-[11px] text-slate-400 font-medium">Criterion: Critical Thinking (5 pts)</span>
          </div>
          <p className="text-xs text-slate-500 pl-8">
            Analyze the potential ripple effects, escalating risks, and long-term socio-economic, emotional, or environmental damages if no ICT intervention is made.
          </p>
          <div className="pl-8">
            <textarea
              rows={4}
              value={data.consequences}
              onChange={(e) => onChange({ ...data, consequences: e.target.value })}
              placeholder="Evaluate the short-term and long-term societal consequences if this problem continues..."
              className="w-full p-3.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900 leading-relaxed"
            />
            <div className="flex justify-between items-center text-[11px] text-slate-400 mt-1">
              <span>Highlight the urgency of mobilizing an ICT-driven advocacy response.</span>
              <span>{data.consequences.trim().length} characters</span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex justify-between items-center pt-2">
        <button
          type="button"
          onClick={onOpenBrief}
          className="text-xs text-slate-500 hover:text-slate-800 underline font-medium"
        >
          Need to review the community scenario again?
        </button>
        <button
          type="button"
          disabled={!isFormValid}
          onClick={onNext}
          className={`px-6 py-3 rounded-xl font-bold text-xs sm:text-sm flex items-center space-x-2 shadow-xs transition-all ${
            isFormValid
              ? 'bg-blue-700 hover:bg-blue-800 text-white cursor-pointer hover:shadow-md'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed'
          }`}
        >
          <span>Save & Proceed to Phase 2: Online Research</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
