import React from 'react';
import {
  ShieldAlert,
  CheckCircle,
  XCircle,
  Edit3,
  ArrowRight,
  ArrowLeft,
  Scale,
  Lock,
} from 'lucide-react';
import { DilemmaResponse, EthicsDilemma, Phase5Response, ScenarioData } from '../types/simulator';

interface Phase5DigitalEthicsProps {
  scenario: ScenarioData;
  data: Phase5Response;
  onChange: (updated: Phase5Response) => void;
  onNext: () => void;
  onBack: () => void;
}

export const Phase5DigitalEthics: React.FC<Phase5DigitalEthicsProps> = ({
  scenario,
  data,
  onChange,
  onNext,
  onBack,
}) => {
  const handleDecision = (dilemmaId: string, decision: 'Approve' | 'Reject' | 'Modify') => {
    const existing = data.dilemmas[dilemmaId] || { decision: 'Reject', justification: '' };
    onChange({
      ...data,
      dilemmas: {
        ...data.dilemmas,
        [dilemmaId]: {
          ...existing,
          decision,
        },
      },
    });
  };

  const handleJustification = (dilemmaId: string, justification: string) => {
    const existing = data.dilemmas[dilemmaId] || { decision: 'Reject', justification: '' };
    onChange({
      ...data,
      dilemmas: {
        ...data.dilemmas,
        [dilemmaId]: {
          ...existing,
          justification,
        },
      },
    });
  };

  const isFormValid = scenario.dilemmas.every((dil) => {
    const dRes = data.dilemmas[dil.id];
    return dRes && dRes.decision && dRes.justification.trim().length >= 15;
  });

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 sm:px-6 space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-bold text-blue-700 uppercase tracking-wider mb-1">
            <span>Phase 5 of 6</span>
            <span>•</span>
            <span>Competency: Online Safety, Security, Ethics & Netiquette</span>
          </div>
          <h1 className="text-xl font-extrabold text-slate-900">Digital Ethics & Netiquette Simulation</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Resolve 5 critical ethical dilemmas encountered during your community advocacy.
          </p>
        </div>
        <div className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-3 py-1.5 rounded-lg text-xs font-bold shrink-0">
          Max 20 Pts (4 Pts Each)
        </div>
      </div>

      {/* Guiding Legal & Ethical Anchor Banner */}
      <div className="bg-slate-900 text-white rounded-xl p-4.5 shadow-xs flex items-start space-x-3 text-xs">
        <Scale className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-bold text-slate-200">
            Philippine Legal & Digital Citizenship Frameworks to Guide Your Decisions:
          </p>
          <div className="flex flex-wrap gap-2 text-[11px] text-slate-300 pt-1">
            <span className="bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
              • RA 10173 (Data Privacy Act)
            </span>
            <span className="bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
              • RA 8293 (Intellectual Property Code)
            </span>
            <span className="bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
              • RA 10627 (Anti-Bullying Act)
            </span>
            <span className="bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
              • DepEd Child Protection Policy (DO 40, s. 2012)
            </span>
            <span className="bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
              • Netiquette & Non-Maleficence
            </span>
          </div>
        </div>
      </div>

      {/* Dilemmas list */}
      <div className="space-y-5">
        {scenario.dilemmas.map((dil: EthicsDilemma, index: number) => {
          const currentRes = data.dilemmas[dil.id] || { decision: undefined, justification: '' };

          return (
            <div
              key={dil.id}
              className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden transition-all hover:border-slate-300"
            >
              <div className="bg-slate-50 border-b border-slate-200 px-5 py-3 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="w-5 h-5 rounded-full bg-blue-700 text-white text-[11px] font-bold flex items-center justify-center">
                    {index + 1}
                  </span>
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                    Dilemma {index + 1}: {dil.context}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 font-mono">4 Points</div>
              </div>

              <div className="p-5 space-y-4">
                {/* Situation text */}
                <div className="bg-amber-50/70 border-l-4 border-amber-500 p-3.5 rounded-r-lg text-xs text-slate-800 leading-relaxed font-medium">
                  "{dil.situation}"
                </div>

                {/* 3 Decision options */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                    Your Ethical Action Choice:
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    {/* Approve */}
                    <button
                      type="button"
                      onClick={() => handleDecision(dil.id, 'Approve')}
                      className={`flex items-center justify-center space-x-2 py-2.5 px-3 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                        currentRes.decision === 'Approve'
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs ring-2 ring-emerald-500/20'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <CheckCircle className="w-4 h-4" />
                      <span>Approve</span>
                    </button>

                    {/* Reject */}
                    <button
                      type="button"
                      onClick={() => handleDecision(dil.id, 'Reject')}
                      className={`flex items-center justify-center space-x-2 py-2.5 px-3 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                        currentRes.decision === 'Reject'
                          ? 'bg-rose-600 text-white border-rose-600 shadow-xs ring-2 ring-rose-500/20'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <XCircle className="w-4 h-4" />
                      <span>Reject</span>
                    </button>

                    {/* Modify */}
                    <button
                      type="button"
                      onClick={() => handleDecision(dil.id, 'Modify')}
                      className={`flex items-center justify-center space-x-2 py-2.5 px-3 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                        currentRes.decision === 'Modify'
                          ? 'bg-amber-600 text-white border-amber-600 shadow-xs ring-2 ring-amber-500/20'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <Edit3 className="w-4 h-4" />
                      <span>Modify / Adapt</span>
                    </button>
                  </div>
                </div>

                {/* Justification Textarea */}
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Justify Your Decision:
                  </label>
                  <p className="text-[11px] text-slate-500">
                    Explain why you chose this action. Cite principles of online ethics, user safety, Philippine laws, or digital citizenship etiquette:
                  </p>
                  <textarea
                    rows={3}
                    value={currentRes.justification}
                    onChange={(e) => handleJustification(dil.id, e.target.value)}
                    placeholder="State your ethical justification clearly (e.g. why privacy must be protected, how fair use applies, or alternative constructive paths)..."
                    className="w-full p-3 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900 leading-relaxed"
                  />
                  <div className="text-right text-[11px] text-slate-400">
                    {currentRes.justification.trim().length} characters
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Navigation */}
      <div className="flex justify-between items-center pt-2">
        <button
          type="button"
          onClick={onBack}
          className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-100 flex items-center space-x-2 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Content Creation</span>
        </button>

        <button
          type="button"
          disabled={!isFormValid}
          onClick={onNext}
          className={`px-6 py-3 rounded-xl font-bold text-xs sm:text-sm flex items-center space-x-2 shadow-xs transition-all ${
            isFormValid
              ? 'bg-blue-700 hover:bg-blue-800 text-white cursor-pointer hover:shadow-md'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed'
          }`}
        >
          <span>Save & Proceed to Phase 6: Reflection</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
