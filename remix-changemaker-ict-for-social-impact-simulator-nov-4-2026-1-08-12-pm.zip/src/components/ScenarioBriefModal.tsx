import React from 'react';
import { X, MapPin, Users, AlertTriangle, BookOpen } from 'lucide-react';
import { ScenarioData } from '../types/simulator';

interface ScenarioBriefModalProps {
  scenario: ScenarioData | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ScenarioBriefModal: React.FC<ScenarioBriefModalProps> = ({
  scenario,
  isOpen,
  onClose,
}) => {
  if (!isOpen || !scenario) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden transform transition-all">
        {/* Header */}
        <div className="bg-blue-800 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <BookOpen className="w-5 h-5 text-emerald-300" />
            <div>
              <span className="text-xs uppercase tracking-wider font-semibold text-blue-200">
                Community Advocacy Brief
              </span>
              <h2 className="text-lg font-bold leading-tight">{scenario.title}</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-blue-200 hover:text-white p-1 rounded-lg hover:bg-blue-700/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 max-h-[75vh] overflow-y-auto space-y-4 text-sm text-slate-700">
          {/* Location & Context */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 p-3.5 rounded-lg border border-slate-200">
            <div className="flex items-start space-x-2">
              <MapPin className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-semibold text-slate-500">Location</p>
                <p className="text-xs font-medium text-slate-800">{scenario.location}</p>
              </div>
            </div>
            <div className="flex items-start space-x-2">
              <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-semibold text-slate-500">Advocacy Domain</p>
                <p className="text-xs font-medium text-slate-800">{scenario.category}</p>
              </div>
            </div>
          </div>

          {/* Narrative */}
          <div>
            <h3 className="text-xs uppercase tracking-wider font-bold text-slate-500 mb-2">
              Community Context & Detailed Scenario
            </h3>
            <div className="bg-white p-4 rounded-lg border border-slate-200 text-slate-800 leading-relaxed whitespace-pre-line text-sm">
              {scenario.narrative}
            </div>
          </div>

          {/* Core Challenge */}
          <div className="bg-amber-50 border-l-4 border-amber-500 p-3 rounded-r-lg">
            <p className="text-xs font-bold text-amber-900">Your Team's Core Mission Challenge</p>
            <p className="text-xs text-amber-800 mt-0.5">{scenario.coreChallenge}</p>
          </div>

          {/* Key Stakeholders */}
          <div>
            <div className="flex items-center space-x-2 text-xs font-bold text-slate-600 mb-2">
              <Users className="w-4 h-4 text-blue-600" />
              <span>Key Community Stakeholders to Consider:</span>
            </div>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {scenario.keyStakeholders.map((sh, idx) => (
                <li
                  key={idx}
                  className="bg-slate-50 px-3 py-1.5 rounded text-xs text-slate-700 border border-slate-200 flex items-center"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mr-2 shrink-0"></span>
                  <span>{sh}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors"
          >
            Got It, Back to Assessment
          </button>
        </div>
      </div>
    </div>
  );
};
