import React from 'react';
import {
  Search,
  ExternalLink,
  CheckCircle,
  AlertOctagon,
  ArrowRight,
  ArrowLeft,
  FileCheck2,
  ShieldAlert,
  Globe,
  Share2,
} from 'lucide-react';
import { Phase2Response, ResearchSource, ScenarioData, SourceEvaluationResponse } from '../types/simulator';

interface Phase2ResearchSkillsProps {
  scenario: ScenarioData;
  data: Phase2Response;
  onChange: (updated: Phase2Response) => void;
  onNext: () => void;
  onBack: () => void;
}

export const Phase2ResearchSkills: React.FC<Phase2ResearchSkillsProps> = ({
  scenario,
  data,
  onChange,
  onNext,
  onBack,
}) => {
  const handleUpdateEvaluation = (
    srcId: string,
    field: keyof SourceEvaluationResponse,
    value: any
  ) => {
    const existing = data.evaluations[srcId] || {
      sourceId: srcId,
      userCredibility: 'credible',
      justification: '',
      identifiedRedFlags: '',
    };

    const updated = {
      ...existing,
      [field]: value,
    };

    onChange({
      ...data,
      evaluations: {
        ...data.evaluations,
        [srcId]: updated,
      },
    });
  };

  const isFormValid =
    scenario.researchSources.every((src) => {
      const evalData = data.evaluations[src.id];
      return evalData && evalData.justification.trim().length >= 15;
    }) && data.verificationMethods.trim().length >= 25;

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 sm:px-6 space-y-6">
      {/* Phase Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-bold text-blue-700 uppercase tracking-wider mb-1">
            <span>Phase 2 of 6</span>
            <span>•</span>
            <span>Competency: Online Research & Information Evaluation</span>
          </div>
          <h1 className="text-xl font-extrabold text-slate-900">Online Research & Source Verification</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Evaluate digital artifacts from the field. Distinguish between credible evidence and online misinformation before designing your advocacy.
          </p>
        </div>
        <div className="flex items-center space-x-2 shrink-0">
          <div className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-3 py-1.5 rounded-lg text-xs font-bold">
            Max 20 Pts
          </div>
        </div>
      </div>

      {/* Instructions callout */}
      <div className="bg-blue-50 border-l-4 border-blue-600 p-4 rounded-r-xl text-xs text-blue-900">
        <p className="font-bold text-sm mb-1">Task Instructions:</p>
        <p className="leading-relaxed">
          Review the four digital artifacts collected from community reports, official gazettes, and social media below.
          For each source:
          (1) Decide if it is <strong>Credible</strong> or <strong>Questionable</strong>,
          (2) Justify your classification (evaluating author credentials, domain authority, currency, and evidence), and
          (3) Identify any misinformation red flags. Then, recommend your overall verification strategy.
        </p>
      </div>

      {/* Sources Grid */}
      <div className="space-y-6">
        {scenario.researchSources.map((src: ResearchSource, index: number) => {
          const evalData = data.evaluations[src.id] || {
            sourceId: src.id,
            userCredibility: 'credible',
            justification: '',
            identifiedRedFlags: '',
          };

          return (
            <div
              key={src.id}
              className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden transition-all hover:border-slate-300"
            >
              {/* Source Header Bar */}
              <div className="bg-slate-50 border-b border-slate-200 px-5 py-3 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center space-x-2">
                  <span className="w-5 h-5 rounded-full bg-slate-700 text-white text-[11px] font-bold flex items-center justify-center">
                    {index + 1}
                  </span>
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-600">
                    {src.type.replace('_', ' ')}
                  </span>
                  <span className="text-slate-300">•</span>
                  <span className="text-xs font-semibold text-slate-800 truncate max-w-xs sm:max-w-md">
                    {src.publisher}
                  </span>
                </div>
                <div className="flex items-center space-x-2 text-[11px] text-slate-500 font-mono">
                  <span>{src.publishDate}</span>
                </div>
              </div>

              {/* Source Content Preview */}
              <div className="p-5 space-y-3">
                <h3 className="text-sm font-bold text-slate-900 flex items-start justify-between">
                  <span>{src.title}</span>
                </h3>

                <div className="flex items-center space-x-3 text-xs text-slate-500">
                  <span>By: <strong className="text-slate-700">{src.author}</strong></span>
                  <span>•</span>
                  <span className="flex items-center space-x-1 text-blue-600 truncate max-w-xs">
                    <Globe className="w-3 h-3 shrink-0" />
                    <span className="truncate">{src.url}</span>
                  </span>
                </div>

                {/* Excerpt Box */}
                <div className="bg-slate-50 border-l-3 border-slate-400 p-3.5 rounded-r-lg text-xs text-slate-700 leading-relaxed font-sans italic">
                  "{src.excerpt}"
                </div>

                {/* Student Evaluation Section */}
                <div className="pt-3 mt-3 border-t border-slate-100 space-y-4">
                  {/* Radio Choice: Credible vs Questionable */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                      Source Credibility Assessment:
                    </label>
                    <div className="grid grid-cols-2 gap-3 max-w-md">
                      <button
                        type="button"
                        onClick={() => handleUpdateEvaluation(src.id, 'userCredibility', 'credible')}
                        className={`flex items-center justify-center space-x-2 py-2.5 px-3 rounded-lg border text-xs font-bold transition-all ${
                          evalData.userCredibility === 'credible'
                            ? 'bg-emerald-50 border-emerald-500 text-emerald-800 ring-2 ring-emerald-500/20'
                            : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <CheckCircle className="w-4 h-4 text-emerald-600" />
                        <span>Credible Information</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleUpdateEvaluation(src.id, 'userCredibility', 'questionable')}
                        className={`flex items-center justify-center space-x-2 py-2.5 px-3 rounded-lg border text-xs font-bold transition-all ${
                          evalData.userCredibility === 'questionable'
                            ? 'bg-rose-50 border-rose-500 text-rose-800 ring-2 ring-rose-500/20'
                            : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <AlertOctagon className="w-4 h-4 text-rose-600" />
                        <span>Questionable / Misinformation</span>
                      </button>
                    </div>
                  </div>

                  {/* Justification Textarea */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Explain Why (Evaluate author credibility, domain reliability, citations, and purpose):
                    </label>
                    <textarea
                      rows={2}
                      value={evalData.justification}
                      onChange={(e) => handleUpdateEvaluation(src.id, 'justification', e.target.value)}
                      placeholder="Why do you consider this source trustworthy or doubtful? Point out concrete evidence..."
                      className="w-full p-2.5 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900"
                    />
                  </div>

                  {/* Red flags or corroboration */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Identified Red Flags or Key Supporting Elements:
                    </label>
                    <input
                      type="text"
                      value={evalData.identifiedRedFlags}
                      onChange={(e) => handleUpdateEvaluation(src.id, 'identifiedRedFlags', e.target.value)}
                      placeholder="e.g., Clickbait headline, lack of verified author, peer-reviewed data, official government portal..."
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900"
                    />
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Final Verification Strategy Box */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-3">
        <div className="flex items-center space-x-2">
          <FileCheck2 className="w-5 h-5 text-blue-700" />
          <h2 className="text-sm font-bold text-slate-900">
            Recommended Information Verification Strategy
          </h2>
          <span className="text-[11px] text-slate-400 font-medium ml-auto">Criterion: Verification Strategy (6 pts)</span>
        </div>
        <p className="text-xs text-slate-500 leading-relaxed">
          What verification methods and digital research tools do you recommend for your youth advocacy team and community members to confirm dubious claims before taking action?
          (e.g., lateral reading, reverse image searching, consulting Philippine Fact-Check Network / VERA Files / Rappler, verifying official gazettes and statutory portals).
        </p>
        <textarea
          rows={4}
          value={data.verificationMethods}
          onChange={(e) => onChange({ ...data, verificationMethods: e.target.value })}
          placeholder="Outline concrete verification protocols: How will your team fact-check claims, verify images, and cross-reference government data?"
          className="w-full p-3.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900 leading-relaxed"
        />
        <div className="flex justify-between items-center text-[11px] text-slate-400">
          <span>Explain at least 2 distinct verification techniques.</span>
          <span>{data.verificationMethods.trim().length} characters</span>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex justify-between items-center pt-2">
        <button
          type="button"
          onClick={onBack}
          className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-100 flex items-center space-x-2 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Problem Analysis</span>
        </button>

        <button
          type="button"
          disabled={!isFormValid}
          onClick={onNext}
          className={`px-6 py-3 rounded-xl font-bold text-xs sm:text-sm flex items-center space-x-2 shadow-xs transition-all ${
            isFormValid
              ? 'bg-blue-700 hover:bg-blue-800 text-white cursor-pointer hover:shadow-md'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed'
          }`}
        >
          <span>Save & Proceed to Phase 3: ICT Solution</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
