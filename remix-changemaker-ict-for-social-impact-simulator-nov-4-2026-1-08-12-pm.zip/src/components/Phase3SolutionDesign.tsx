import React from 'react';
import {
  Globe,
  Share2,
  Smartphone,
  Bot,
  Image,
  MapPin,
  ArrowRight,
  ArrowLeft,
  Check,
  Target,
  Sparkles,
} from 'lucide-react';
import { ICTPlatform, Phase3Response, ScenarioData } from '../types/simulator';

interface Phase3SolutionDesignProps {
  scenario: ScenarioData;
  data: Phase3Response;
  onChange: (updated: Phase3Response) => void;
  onNext: () => void;
  onBack: () => void;
}

interface PlatformOption {
  id: ICTPlatform;
  label: string;
  badge: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
  bestFor: string;
}

const PLATFORM_OPTIONS: PlatformOption[] = [
  {
    id: 'Website',
    label: 'A. Website / Web Portal',
    badge: 'Information Hub',
    icon: Globe,
    description: 'A centralized portal for community resources, policy documents, verified hotlines, and petition signing.',
    bestFor: 'Structured educational content, archival resources, long-term advocacy campaigns.',
  },
  {
    id: 'Social Media Campaign',
    label: 'B. Social Media Campaign',
    badge: 'High Reach & Virality',
    icon: Share2,
    description: 'Coordinated narrative across TikTok, Facebook, and Instagram leveraging short-form videos and shareable stories.',
    bestFor: 'Rapid youth mobilization, peer engagement, raising broad public awareness.',
  },
  {
    id: 'Mobile App',
    label: 'C. Mobile App (Offline-Ready)',
    badge: 'Utility & Tools',
    icon: Smartphone,
    description: 'Interactive Android/PWA application featuring offline guides, GPS mapping, emergency notifications, and calculators.',
    bestFor: 'Areas with intermittent connectivity, task tracking, disaster safety routing.',
  },
  {
    id: 'Educational Chatbot',
    label: 'D. Educational Chatbot',
    badge: 'Interactive & Anonymous',
    icon: Bot,
    description: 'Automated conversational bot on Messenger or Telegram offering 24/7 triage, anonymous Q&A, and crisis helpline routing.',
    bestFor: 'Sensitive topics requiring high confidentiality (mental health, cyberbullying, reporting).',
  },
  {
    id: 'Infographic Campaign',
    label: 'E. Infographic Campaign',
    badge: 'Visual Literacy',
    icon: Image,
    description: 'High-contrast, multilingual visual posters, carousels, and printable flyers for barangay halls and family chat groups.',
    bestFor: 'Bridging technical jargon, reaching non-tech savvy parents, senior citizens, and market vendors.',
  },
  {
    id: 'Community Reporting Platform',
    label: 'F. Community Reporting Platform',
    badge: 'Citizen Science & Crowdsourcing',
    icon: MapPin,
    description: 'Crowdsourced public incident mapping allowing residents to report waste dumps, hazards, or needs with geo-tagged verification.',
    bestFor: 'Civic accountability, community monitoring, collaborative municipal response.',
  },
];

export const Phase3SolutionDesign: React.FC<Phase3SolutionDesignProps> = ({
  scenario,
  data,
  onChange,
  onNext,
  onBack,
}) => {
  const isFormValid =
    data.platform &&
    data.justification.trim().length >= 20 &&
    data.audience.trim().length >= 20 &&
    data.outcomes.trim().length >= 20;

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 sm:px-6 space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-bold text-blue-700 uppercase tracking-wider mb-1">
            <span>Phase 3 of 6</span>
            <span>•</span>
            <span>Competency: ICT Project for Social Change</span>
          </div>
          <h1 className="text-xl font-extrabold text-slate-900">ICT Solution Design & Audience Profiling</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Select the optimal ICT modality to address your community issue and justify your strategic choices.
          </p>
        </div>
        <div className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-3 py-1.5 rounded-lg text-xs font-bold shrink-0">
          Max 20 Pts
        </div>
      </div>

      {/* Platform selection cards */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <label className="text-sm font-bold text-slate-900">
            Select Your Primary ICT Platform:
          </label>
          <span className="text-[11px] text-slate-400 font-medium">Criterion: Relevance (7 pts)</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {PLATFORM_OPTIONS.map((opt) => {
            const Icon = opt.icon;
            const isSelected = data.platform === opt.id;

            return (
              <div
                key={opt.id}
                onClick={() => onChange({ ...data, platform: opt.id })}
                className={`cursor-pointer rounded-xl p-4 border text-left transition-all relative flex flex-col justify-between ${
                  isSelected
                    ? 'border-blue-600 bg-blue-50/70 ring-2 ring-blue-600/20 shadow-xs'
                    : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/50'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        isSelected ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    {isSelected && (
                      <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </span>
                    )}
                  </div>

                  <h3 className="text-xs font-bold text-slate-900 mb-1">{opt.label}</h3>
                  <p className="text-[11px] text-slate-600 leading-relaxed mb-2">
                    {opt.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100 text-[10px] text-slate-500">
                  <span className="font-semibold text-slate-700">Best for:</span> {opt.bestFor}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Justification & Planning Inputs */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-6">
        {/* Choice of platform justification */}
        <div className="space-y-2">
          <div className="flex items-start justify-between">
            <label className="text-sm font-bold text-slate-900">
              1. Justify Your Choice of Platform
            </label>
            <span className="text-[11px] text-slate-400 font-medium">Relevance to Issue</span>
          </div>
          <p className="text-xs text-slate-500">
            Why is <strong className="text-blue-700">{data.platform || 'this platform'}</strong> the most appropriate ICT mechanism to resolve the specific problem in {scenario.location}? How does its architecture directly tackle the root causes?
          </p>
          <textarea
            rows={4}
            value={data.justification}
            onChange={(e) => onChange({ ...data, justification: e.target.value })}
            placeholder="Explain why this platform outmatches other alternatives for your specific community challenge..."
            className="w-full p-3.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900 leading-relaxed"
          />
          <div className="flex justify-between items-center text-[11px] text-slate-400">
            <span>Provide concrete arguments linking the technical tool to the community issue.</span>
            <span>{data.justification.trim().length} characters</span>
          </div>
        </div>

        {/* Audience Profiling */}
        <div className="space-y-2 pt-4 border-t border-slate-100">
          <div className="flex items-start justify-between">
            <label className="text-sm font-bold text-slate-900">
              2. Target Audience Profiling
            </label>
            <span className="text-[11px] text-slate-400 font-medium">Criterion: Audience Profiling (7 pts)</span>
          </div>
          <p className="text-xs text-slate-500">
            Profile your primary users. What are their demographics (age, education), digital access levels (free Wi-Fi vs limited mobile data, smartphones vs feature phones), language preferences (Filipino/English/vernacular), and tech literacy?
          </p>
          <textarea
            rows={4}
            value={data.audience}
            onChange={(e) => onChange({ ...data, audience: e.target.value })}
            placeholder="Describe your audience's digital habits, socioeconomic context, and accessibility constraints..."
            className="w-full p-3.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900 leading-relaxed"
          />
          <div className="flex justify-between items-center text-[11px] text-slate-400">
            <span>Demonstrate realistic understanding of Philippine digital divides.</span>
            <span>{data.audience.trim().length} characters</span>
          </div>
        </div>

        {/* Expected Outcomes */}
        <div className="space-y-2 pt-4 border-t border-slate-100">
          <div className="flex items-start justify-between">
            <label className="text-sm font-bold text-slate-900">
              3. Expected Outcomes & Measurable Social Impact
            </label>
            <span className="text-[11px] text-slate-400 font-medium">Criterion: Feasibility & Impact (6 pts)</span>
          </div>
          <p className="text-xs text-slate-500">
            What tangible changes do you expect in your community? Define at least two measurable indicators or key performance indicators (KPIs) (e.g. reduction in reported cases, number of verified reports, community adoption rate).
          </p>
          <textarea
            rows={4}
            value={data.outcomes}
            onChange={(e) => onChange({ ...data, outcomes: e.target.value })}
            placeholder="Specify measurable targets, behavioral changes, and community outcomes within 3 to 6 months..."
            className="w-full p-3.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900 leading-relaxed"
          />
          <div className="flex justify-between items-center text-[11px] text-slate-400">
            <span>Include both quantitative metrics and qualitative behavioral transformation.</span>
            <span>{data.outcomes.trim().length} characters</span>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex justify-between items-center pt-2">
        <button
          type="button"
          onClick={onBack}
          className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-100 flex items-center space-x-2 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Research Skills</span>
        </button>

        <button
          type="button"
          disabled={!isFormValid}
          onClick={onNext}
          className={`px-6 py-3 rounded-xl font-bold text-xs sm:text-sm flex items-center space-x-2 shadow-xs transition-all ${
            isFormValid
              ? 'bg-blue-700 hover:bg-blue-800 text-white cursor-pointer hover:shadow-md'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed'
          }`}
        >
          <span>Save & Proceed to Phase 4: Content Creation</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
