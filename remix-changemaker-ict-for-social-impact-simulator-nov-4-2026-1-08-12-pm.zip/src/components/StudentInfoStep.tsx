import React, { useState } from 'react';
import { User, BookOpen, Clock, Hash, Sparkles, Award, ArrowRight } from 'lucide-react';
import { StudentInfo } from '../types/simulator';

interface StudentInfoStepProps {
  onStart: (info: StudentInfo) => void;
}

const COMMON_SECTIONS = [
  'Grade 11 - STEM A (Newton)',
  'Grade 11 - STEM B (Galileo)',
  'Grade 11 - HUMSS A (Plato)',
  'Grade 11 - ABM A (Galbraith)',
  'Grade 11 - TVL ICT (Turing)',
  'Grade 12 - STEM A (Curie)',
  'Grade 12 - HUMSS B (Rizal)',
  'Grade 12 - ABM B (Keynes)',
  'Grade 12 - TVL ICT (Lovelace)',
  'Grade 12 - GAS A (Einstein)',
];

export const StudentInfoStep: React.FC<StudentInfoStepProps> = ({ onStart }) => {
  const [name, setName] = useState('');
  const [section, setSection] = useState(COMMON_SECTIONS[0]);
  const [isCustomSection, setIsCustomSection] = useState(false);
  const [customSection, setCustomSection] = useState('');
  const [studentNumber, setStudentNumber] = useState('');
  const [dateTime] = useState(() =>
    new Date().toLocaleString('en-PH', {
      dateStyle: 'medium',
      timeStyle: 'short',
    })
  );
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = name.trim();
    if (!trimmedName) {
      setErrorMessage('Student Name is required to begin the assessment.');
      return;
    }

    const finalSection = isCustomSection ? customSection.trim() : section;
    if (!finalSection) {
      setErrorMessage('Please specify your class section.');
      return;
    }

    onStart({
      name: trimmedName,
      section: finalSection,
      studentNumber: studentNumber.trim() || undefined,
      dateTime,
    });
  };

  return (
    <div className="max-w-3xl mx-auto py-8 px-4 sm:px-6">
      {/* Intro hero card */}
      <div className="bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl mb-8 relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-8 w-64 h-64 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10">
          <div className="inline-flex items-center space-x-2 bg-blue-700/60 text-emerald-300 px-3 py-1 rounded-full text-xs font-semibold mb-4 border border-blue-600">
            <Sparkles className="w-3.5 h-3.5" />
            <span>DepEd Senior High School • Empowerment Technologies</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight mb-2">
            ChangeMaker: ICT for Social Impact Simulator
          </h1>
          <p className="text-blue-100 text-sm sm:text-base leading-relaxed max-w-2xl">
            Step into the role of a youth advocacy team leader solving a real-world Philippine community challenge.
            Demonstrate your authentic application of ICT for social change, digital citizenship, research verification,
            content development, and online ethics.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-blue-700/60 text-xs">
            <div>
              <span className="block text-blue-300">Total Score</span>
              <span className="font-bold text-white text-base">100 Points</span>
            </div>
            <div>
              <span className="block text-blue-300">Phases</span>
              <span className="font-bold text-white text-base">6 Simulation Steps</span>
            </div>
            <div>
              <span className="block text-blue-300">Scenario</span>
              <span className="font-bold text-white text-base">Philippine Localized</span>
            </div>
            <div>
              <span className="block text-blue-300">Recognition</span>
              <span className="font-bold text-white text-base">Certificate of Impact</span>
            </div>
          </div>
        </div>
      </div>

      {/* Student Form Card */}
      <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6 sm:p-8">
        <div className="flex items-center space-x-3 pb-5 mb-6 border-b border-slate-100">
          <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
            <User className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900">Student Assessment Registration</h2>
            <p className="text-xs text-slate-500">
              Please enter your official enrollment information. This data will be recorded on your final certificate and teacher dashboard.
            </p>
          </div>
        </div>

        {errorMessage && (
          <div className="mb-6 p-3.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg text-xs font-medium">
            {errorMessage}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Student Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Full Student Name <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  if (errorMessage) setErrorMessage('');
                }}
                placeholder="e.g., Juan Dela Cruz Jr."
                className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900"
              />
              <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">Official name as listed in the DepEd School Form 1 (SF1).</p>
          </div>

          {/* Section Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Grade & Section <span className="text-rose-500">*</span>
            </label>
            {!isCustomSection ? (
              <div className="space-y-2">
                <div className="relative">
                  <select
                    value={section}
                    onChange={(e) => {
                      if (e.target.value === '__custom__') {
                        setIsCustomSection(true);
                      } else {
                        setSection(e.target.value);
                      }
                    }}
                    className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900"
                  >
                    {COMMON_SECTIONS.map((sec) => (
                      <option key={sec} value={sec}>
                        {sec}
                      </option>
                    ))}
                    <option value="__custom__">-- Other / Specify Custom Section --</option>
                  </select>
                  <BookOpen className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex space-x-2">
                  <input
                    type="text"
                    required
                    value={customSection}
                    onChange={(e) => setCustomSection(e.target.value)}
                    placeholder="e.g., Grade 11 - TVL ICT 2"
                    className="flex-1 px-4 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900"
                  />
                  <button
                    type="button"
                    onClick={() => setIsCustomSection(false)}
                    className="px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg border border-slate-300"
                  >
                    Preset List
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Student Number (Optional) */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                LRN / Student Number <span className="text-slate-400 font-normal">(Optional)</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={studentNumber}
                  onChange={(e) => setStudentNumber(e.target.value)}
                  placeholder="e.g., 102938475612"
                  className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900"
                />
                <Hash className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              </div>
            </div>

            {/* Date & Time (Read-only permanent timestamp) */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Assessment Date & Time
              </label>
              <div className="relative">
                <input
                  type="text"
                  readOnly
                  value={dateTime}
                  className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-100 border border-slate-200 rounded-lg text-slate-600 cursor-not-allowed font-mono text-xs"
                />
                <Clock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              </div>
            </div>
          </div>

          {/* Assessment Protocol Notice */}
          <div className="bg-blue-50/70 border border-blue-200 rounded-lg p-4 text-xs text-blue-900 space-y-1.5">
            <div className="flex items-center space-x-1.5 font-bold text-blue-950">
              <Award className="w-4 h-4 text-blue-700" />
              <span>Assessment Protocol & Instructions</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-blue-800 text-[12px] leading-relaxed">
              <li>Once you begin, an authentic Philippine advocacy scenario will be randomly assigned to your session.</li>
              <li>Complete all 6 phases: Problem Analysis, Research Verification, Solution Design, Content Creation, Digital Ethics, and Reflection.</li>
              <li>Your responses will be evaluated using DepEd Empowerment Technologies criteria (Total: 100 points).</li>
              <li>Scoring and constructive AI feedback will be computed upon submission.</li>
            </ul>
          </div>

          {/* Submit button */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3.5 px-6 bg-gradient-to-r from-blue-700 to-blue-800 hover:from-blue-800 hover:to-blue-900 text-white font-bold rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center space-x-2 text-sm sm:text-base cursor-pointer"
            >
              <span>Begin Advocacy Simulation</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
