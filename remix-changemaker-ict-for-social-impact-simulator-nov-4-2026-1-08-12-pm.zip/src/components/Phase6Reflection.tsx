import React, { useState } from 'react';
import {
  HeartHandshake,
  CheckCircle2,
  ArrowLeft,
  Sparkles,
  AlertCircle,
  HelpCircle,
  Send,
} from 'lucide-react';
import { Phase6Response, ScenarioData } from '../types/simulator';

interface Phase6ReflectionProps {
  scenario: ScenarioData;
  data: Phase6Response;
  onChange: (updated: Phase6Response) => void;
  onSubmit: () => void;
  onBack: () => void;
  isEvaluating: boolean;
}

export const Phase6Reflection: React.FC<Phase6ReflectionProps> = ({
  scenario,
  data,
  onChange,
  onSubmit,
  onBack,
  isEvaluating,
}) => {
  const words = data.essay.trim() ? data.essay.trim().split(/\s+/).filter(Boolean) : [];
  const wordCount = words.length;

  const isWordCountAdequate = wordCount >= 150 && wordCount <= 260;
  const isTooShort = wordCount < 150;
  const isTooLong = wordCount > 260;

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 sm:px-6 space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-bold text-blue-700 uppercase tracking-wider mb-1">
            <span>Phase 6 of 6</span>
            <span>•</span>
            <span>Final Synthesis & Personal Commitment</span>
          </div>
          <h1 className="text-xl font-extrabold text-slate-900">Empowerment Technologies Reflection</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Reflect on the broader role of digital tools, personal responsibility, and community transformation.
          </p>
        </div>
        <div className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-3 py-1.5 rounded-lg text-xs font-bold shrink-0">
          Max 10 Pts
        </div>
      </div>

      {/* Main Reflection Prompt Box */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="bg-blue-50/70 border-l-4 border-blue-700 p-4 rounded-r-xl">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-900 block mb-1">
            Official Reflection Prompt:
          </span>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
            "How can ICT be used responsibly to create positive social change in your community?"
          </h2>
          <p className="text-xs text-blue-800 mt-2">
            Target Length: <strong>150 to 250 words</strong>. Evaluated on <em>Insight (4 pts)</em>, <em>Understanding of ICT concepts (3 pts)</em>, and <em>Personal community relevance (3 pts)</em>.
          </p>
        </div>

        {/* Guiding Reflection Questions */}
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs text-slate-700 space-y-2">
          <div className="flex items-center space-x-2 font-bold text-slate-800">
            <HelpCircle className="w-4 h-4 text-blue-600" />
            <span>Guiding Inquiries to Deepen Your Synthesis:</span>
          </div>
          <ul className="list-disc list-inside space-y-1 text-slate-600 text-[11px] leading-relaxed pl-1">
            <li>How does digital citizenship go beyond simply following laws to actively improving lives in your barangay or school?</li>
            <li>What did working through the {scenario.category} scenario teach you about the balance between digital engagement and ethical responsibility?</li>
            <li>What personal commitment will you make as a Senior High School student when posting, sharing, or creating digital media?</li>
          </ul>
        </div>

        {/* Textarea */}
        <div className="space-y-2">
          <textarea
            rows={10}
            value={data.essay}
            onChange={(e) => onChange({ essay: e.target.value })}
            placeholder="Write your comprehensive reflection essay here (150–250 words)..."
            className="w-full p-4 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900 leading-relaxed font-sans"
          />

          {/* Word Count Indicator Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-2 pt-1">
            <div className="flex items-center space-x-2">
              <span className="font-semibold text-slate-700">Word Count:</span>
              <span
                className={`font-mono font-bold px-2.5 py-0.5 rounded text-xs ${
                  isWordCountAdequate
                    ? 'bg-emerald-100 text-emerald-800'
                    : isTooShort
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-rose-100 text-rose-800'
                }`}
              >
                {wordCount} / 250 words
              </span>
              {isTooShort && (
                <span className="text-[11px] text-amber-700">
                  (Needs at least {Math.max(0, 150 - wordCount)} more words)
                </span>
              )}
              {isWordCountAdequate && (
                <span className="text-[11px] text-emerald-700 flex items-center space-x-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Optimal word count reached!</span>
                </span>
              )}
              {isTooLong && (
                <span className="text-[11px] text-rose-600">
                  (Slightly over target; aim for concise synthesis)
                </span>
              )}
            </div>

            <span className="text-[11px] text-slate-400">
              {data.essay.trim().length} characters
            </span>
          </div>
        </div>
      </div>

      {/* Submission Final Card */}
      <div className="bg-gradient-to-r from-blue-900 to-indigo-950 text-white rounded-xl p-6 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-base flex items-center space-x-2">
            <Sparkles className="w-5 h-5 text-emerald-400" />
            <span>Ready for Automatic Assessment Evaluation?</span>
          </h3>
          <p className="text-xs text-blue-200 mt-1 max-w-xl">
            Submitting will compute your final 100-point score across all 6 phases, evaluate your performance level, generate personalized constructive feedback from your Community Adviser, and record your assessment permanently.
          </p>
        </div>

        <button
          type="button"
          disabled={wordCount < 50 || isEvaluating}
          onClick={onSubmit}
          className={`px-6 py-3.5 rounded-xl font-bold text-sm shrink-0 flex items-center justify-center space-x-2 shadow-lg transition-all ${
            wordCount >= 50 && !isEvaluating
              ? 'bg-emerald-500 hover:bg-emerald-600 text-white cursor-pointer hover:scale-[1.02]'
              : 'bg-slate-700 text-slate-400 cursor-not-allowed'
          }`}
        >
          {isEvaluating ? (
            <div className="flex items-center space-x-2">
              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>Evaluating Authentic Rubric...</span>
            </div>
          ) : (
            <>
              <Send className="w-4 h-4" />
              <span>Complete Assessment & Compute Score</span>
            </>
          )}
        </button>
      </div>

      {/* Back button */}
      <div className="flex justify-start pt-2">
        <button
          type="button"
          onClick={onBack}
          className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-100 flex items-center space-x-2 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Digital Ethics</span>
        </button>
      </div>
    </div>
  );
};
