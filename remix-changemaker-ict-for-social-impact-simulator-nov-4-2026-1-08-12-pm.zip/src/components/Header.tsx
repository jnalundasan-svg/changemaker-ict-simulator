import React, { useEffect, useState } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  Lock,
  User,
  FileText,
  Check,
  Clock,
  Sparkles,
  CloudCheck,
  RefreshCw,
} from 'lucide-react';
import { StudentInfo } from '../types/simulator';

interface HeaderProps {
  currentPhase: number;
  totalPhases: number;
  studentInfo: StudentInfo | null;
  onOpenTeacher: () => void;
  onOpenScenarioModal: () => void;
  hasScenario: boolean;
  scenarioTitle?: string;
  isCompleted?: boolean;
  lastSavedTime?: string | null;
  isSaving?: boolean;
}

const STEPS = [
  { phase: 1, shortTitle: 'Problem', fullTitle: 'Problem Analysis' },
  { phase: 2, shortTitle: 'Research', fullTitle: 'Online Research' },
  { phase: 3, shortTitle: 'Solution', fullTitle: 'ICT Solution' },
  { phase: 4, shortTitle: 'Content', fullTitle: 'Content Creation' },
  { phase: 5, shortTitle: 'Ethics', fullTitle: 'Digital Ethics' },
  { phase: 6, shortTitle: 'Reflection', fullTitle: 'Final Reflection' },
];

export const Header: React.FC<HeaderProps> = ({
  currentPhase,
  totalPhases,
  studentInfo,
  onOpenTeacher,
  onOpenScenarioModal,
  hasScenario,
  scenarioTitle,
  isCompleted,
  lastSavedTime,
  isSaving,
}) => {
  const isAssessmentActive = studentInfo && currentPhase >= 1 && currentPhase <= 6;
  const phasesRemaining = Math.max(0, 6 - currentPhase);
  const progressPercent = Math.min(
    100,
    Math.round(((currentPhase - 1) / 5) * 100)
  );

  // Subtle flash highlight state whenever save happens
  const [showSavedToast, setShowSavedToast] = useState(false);

  useEffect(() => {
    if (lastSavedTime && !isSaving) {
      setShowSavedToast(true);
      const timer = setTimeout(() => {
        setShowSavedToast(false);
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, [lastSavedTime, isSaving]);

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Title */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-blue-700 flex items-center justify-center text-white font-bold shadow-xs">
              <ShieldCheck className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-slate-900 tracking-tight text-lg">ChangeMaker</span>
                <span className="text-xs bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded">
                  EmpTech SHS
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                ICT for Social Impact & Digital Citizenship Assessment
              </p>
            </div>
          </div>

          {/* Right Action buttons & status */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Interactive Dynamic Autosave Indicator & Toast */}
            {studentInfo && !isCompleted && (
              <div
                className={`flex items-center space-x-1.5 text-xs px-2.5 py-1 rounded-lg border transition-all duration-300 ${
                  isSaving
                    ? 'bg-blue-50 text-blue-700 border-blue-200 animate-pulse'
                    : showSavedToast
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-300 ring-2 ring-emerald-400/20 shadow-xs'
                    : 'bg-slate-50 text-slate-600 border-slate-200'
                }`}
                title={lastSavedTime ? `Last saved locally at ${lastSavedTime}` : 'Autosave active'}
              >
                {isSaving ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 text-blue-600 animate-spin" />
                    <span className="font-medium hidden sm:inline">Saving draft...</span>
                    <span className="font-medium sm:hidden">Saving...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2
                      className={`w-3.5 h-3.5 transition-transform duration-300 ${
                        showSavedToast ? 'text-emerald-600 scale-110' : 'text-emerald-500'
                      }`}
                    />
                    <span className="font-medium hidden md:inline">
                      {showSavedToast ? 'All changes saved' : 'Draft saved'}
                    </span>
                    {lastSavedTime && (
                      <span className="text-[10px] text-slate-400 font-mono hidden lg:inline">
                        ({lastSavedTime})
                      </span>
                    )}
                    <span className="font-medium md:hidden text-[11px]">Saved</span>
                  </>
                )}
              </div>
            )}

            {/* Scenario Quick View button */}
            {hasScenario && (
              <button
                type="button"
                onClick={onOpenScenarioModal}
                className="inline-flex items-center space-x-1.5 px-3 py-1.5 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded border border-blue-200 transition-colors cursor-pointer"
                title="View your assigned community advocacy scenario"
              >
                <FileText className="w-3.5 h-3.5 text-blue-600" />
                <span className="hidden sm:inline">Scenario Brief</span>
              </button>
            )}

            {/* Student info indicator */}
            {studentInfo && (
              <div className="hidden lg:flex items-center space-x-2 text-xs text-slate-600 bg-slate-100 px-3 py-1.5 rounded">
                <User className="w-3.5 h-3.5 text-slate-500" />
                <span className="font-semibold text-slate-800 truncate max-w-[140px]">
                  {studentInfo.name}
                </span>
                <span className="text-slate-400">|</span>
                <span className="text-slate-600 truncate max-w-[120px]">{studentInfo.section}</span>
              </div>
            )}

            {/* Teacher Dashboard Access */}
            <button
              type="button"
              onClick={onOpenTeacher}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded border border-slate-300 transition-colors cursor-pointer"
              title="Teacher / Admin Mode (Password protected)"
            >
              <Lock className="w-3.5 h-3.5 text-slate-600" />
              <span>Teacher Portal</span>
            </button>
          </div>
        </div>

        {/* Enhanced Visual Progress Step Indicator (Visible during active assessment) */}
        {isAssessmentActive && (
          <div className="py-2.5 border-t border-slate-100">
            {/* Top row: Current Phase name, remaining count badge, completion pct */}
            <div className="flex items-center justify-between text-xs mb-2">
              <div className="flex items-center space-x-2">
                <span className="font-bold text-slate-900">
                  Phase {currentPhase} of 6:
                </span>
                <span className="text-blue-700 font-semibold">
                  {STEPS[currentPhase - 1]?.fullTitle}
                </span>
              </div>

              {/* Visual "Phases Remaining" callout */}
              <div className="flex items-center space-x-2">
                <div
                  className={`inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded text-[11px] font-semibold transition-colors ${
                    phasesRemaining === 0
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : phasesRemaining === 1
                      ? 'bg-amber-100 text-amber-800 border border-amber-300'
                      : 'bg-blue-50 text-blue-800 border border-blue-200'
                  }`}
                >
                  <Clock className="w-3 h-3 shrink-0" />
                  <span>
                    {phasesRemaining === 0
                      ? 'Final phase — Ready for scoring!'
                      : phasesRemaining === 1
                      ? '1 phase remaining'
                      : `${phasesRemaining} phases remaining`}
                  </span>
                </div>

                <span className="text-slate-400 font-mono text-[11px] hidden sm:inline">
                  {progressPercent}% Complete
                </span>
              </div>
            </div>

            {/* Step Nodes Track */}
            <div className="relative py-1">
              {/* Connecting background line */}
              <div className="absolute top-1/2 left-3 right-3 -translate-y-1/2 h-1 bg-slate-200 rounded-full z-0" />

              {/* Active progress fill */}
              <div
                className="absolute top-1/2 left-3 -translate-y-1/2 h-1 bg-gradient-to-r from-blue-600 to-emerald-500 rounded-full transition-all duration-300 ease-out z-0"
                style={{ width: `calc((100% - 24px) * ${progressPercent / 100})` }}
              />

              {/* 6 Step Nodes */}
              <div className="relative flex justify-between items-center z-10">
                {STEPS.map((s) => {
                  const isDone = currentPhase > s.phase;
                  const isCurrent = currentPhase === s.phase;
                  const isUpcoming = currentPhase < s.phase;

                  return (
                    <div
                      key={s.phase}
                      className="flex flex-col items-center group cursor-default"
                      title={`Phase ${s.phase}: ${s.fullTitle}`}
                    >
                      {/* Node circle */}
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-[11px] font-bold transition-all ${
                          isDone
                            ? 'bg-emerald-600 text-white shadow-xs'
                            : isCurrent
                            ? 'bg-blue-700 text-white ring-4 ring-blue-100 scale-110 shadow-sm'
                            : 'bg-white border-2 border-slate-300 text-slate-400'
                        }`}
                      >
                        {isDone ? (
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        ) : (
                          <span>{s.phase}</span>
                        )}
                      </div>

                      {/* Step Label (short title) */}
                      <span
                        className={`mt-1 text-[10px] hidden sm:block tracking-tight font-medium transition-colors ${
                          isCurrent
                            ? 'text-blue-800 font-bold'
                            : isDone
                            ? 'text-emerald-700'
                            : 'text-slate-400'
                        }`}
                      >
                        {s.shortTitle}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Scenario subtitle footer in header */}
            {scenarioTitle && (
              <div className="mt-1 text-[11px] text-slate-500 truncate flex items-center space-x-1.5">
                <span className="font-semibold text-slate-700 shrink-0">Assigned Project:</span>
                <span className="italic text-blue-700 truncate">{scenarioTitle}</span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Floating Reassurance Toast when save occurs */}
      {showSavedToast && (
        <div className="fixed bottom-4 right-4 z-50 bg-slate-900/90 text-white px-3.5 py-2 rounded-xl shadow-lg border border-slate-700 text-xs flex items-center space-x-2 animate-fade-in backdrop-blur-xs">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Work preserved in browser memory ({lastSavedTime})</span>
        </div>
      )}
    </header>
  );
};
