import React from 'react';
import {
  Sparkles,
  Megaphone,
  Hash,
  Send,
  Eye,
  ArrowRight,
  ArrowLeft,
  Share2,
  Heart,
  MessageCircle,
  Bookmark,
  ShieldCheck,
} from 'lucide-react';
import { Phase4Response, ScenarioData } from '../types/simulator';

interface Phase4ContentCreationProps {
  scenario: ScenarioData;
  data: Phase4Response;
  onChange: (updated: Phase4Response) => void;
  onNext: () => void;
  onBack: () => void;
}

export const Phase4ContentCreation: React.FC<Phase4ContentCreationProps> = ({
  scenario,
  data,
  onChange,
  onNext,
  onBack,
}) => {
  const isFormValid =
    data.slogan.trim().length >= 5 &&
    data.post.trim().length >= 25 &&
    data.cta.trim().length >= 10 &&
    data.hashtags.trim().length >= 3 &&
    data.caption.trim().length >= 15;

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 sm:px-6 space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-bold text-blue-700 uppercase tracking-wider mb-1">
            <span>Phase 4 of 6</span>
            <span>•</span>
            <span>Competency: ICT Content Development & Publishing</span>
          </div>
          <h1 className="text-xl font-extrabold text-slate-900">Advocacy Content Creation Challenge</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Craft persuasive digital communication materials tailored to your community audience.
          </p>
        </div>
        <div className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-3 py-1.5 rounded-lg text-xs font-bold shrink-0">
          Max 15 Pts
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Form Inputs (Left Column) */}
        <div className="lg:col-span-7 space-y-5 bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
          {/* Task 1: Campaign Slogan */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center justify-between">
              <span>1. Campaign Slogan</span>
              <span className="text-[11px] text-slate-400 font-normal">Catchy & Memorable</span>
            </label>
            <input
              type="text"
              value={data.slogan}
              onChange={(e) => onChange({ ...data, slogan: e.target.value })}
              placeholder="e.g., Ligtas ang Bawat Tipa: Piliin ang Pagkalinga sa Social Media"
              className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900 font-medium"
            />
            <p className="text-[11px] text-slate-400">
              A concise, inspiring motto that captures the core spirit of your advocacy.
            </p>
          </div>

          {/* Task 2: Social Media Post */}
          <div className="space-y-1.5 pt-3 border-t border-slate-100">
            <label className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center justify-between">
              <span>2. Social Media Post Copy</span>
              <span className="text-[11px] text-slate-400 font-normal">Persuasiveness & Clarity</span>
            </label>
            <textarea
              rows={4}
              value={data.post}
              onChange={(e) => onChange({ ...data, post: e.target.value })}
              placeholder="Write an engaging post: hook the reader, present the community problem, and explain why change is urgently needed..."
              className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900 leading-relaxed"
            />
            <div className="flex justify-between items-center text-[11px] text-slate-400">
              <span>Use conversational yet respectful Filipino/English tone.</span>
              <span>{data.post.trim().length} chars</span>
            </div>
          </div>

          {/* Task 3: Call-To-Action (CTA) */}
          <div className="space-y-1.5 pt-3 border-t border-slate-100">
            <label className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center justify-between">
              <span>3. Call-To-Action (CTA)</span>
              <span className="text-[11px] text-slate-400 font-normal">Direct & Action-Oriented</span>
            </label>
            <input
              type="text"
              value={data.cta}
              onChange={(e) => onChange({ ...data, cta: e.target.value })}
              placeholder="e.g., Sumali sa ating offline youth dialogue sa Barangay Hall ngayong Sabado!"
              className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900 font-semibold text-blue-900"
            />
            <p className="text-[11px] text-slate-400">
              What specific action should the reader take right now? (Sign, attend, report, share).
            </p>
          </div>

          {/* Task 4: Hashtags */}
          <div className="space-y-1.5 pt-3 border-t border-slate-100">
            <label className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center justify-between">
              <span>4. Strategic Hashtags</span>
              <span className="text-[11px] text-slate-400 font-normal">Discoverability</span>
            </label>
            <input
              type="text"
              value={data.hashtags}
              onChange={(e) => onChange({ ...data, hashtags: e.target.value })}
              placeholder="#EmpTechForGood #BayanihanDigital #CyberSafetyPH"
              className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-blue-700 font-mono text-xs"
            />
            <p className="text-[11px] text-slate-400">
              Provide 3 to 5 campaign hashtags separated by spaces.
            </p>
          </div>

          {/* Task 5: Caption for Infographic */}
          <div className="space-y-1.5 pt-3 border-t border-slate-100">
            <label className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center justify-between">
              <span>5. Caption for Infographic</span>
              <span className="text-[11px] text-slate-400 font-normal">Accessible Summary</span>
            </label>
            <textarea
              rows={3}
              value={data.caption}
              onChange={(e) => onChange({ ...data, caption: e.target.value })}
              placeholder="Write a concise caption to accompany a visual poster or infographic summarizing 3 key takeaways..."
              className="w-full p-3 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900 leading-relaxed"
            />
            <p className="text-[11px] text-slate-400">
              Ensure text is easy to read for mobile users scrolling through image feeds.
            </p>
          </div>
        </div>

        {/* Live Social Card Mockup Preview (Right Column) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-100 rounded-xl p-3 border border-slate-200 flex items-center justify-between">
            <div className="flex items-center space-x-2 text-xs font-bold text-slate-700">
              <Eye className="w-4 h-4 text-blue-600" />
              <span>Live Social Media Card Mockup</span>
            </div>
            <span className="text-[10px] text-emerald-700 bg-emerald-100 font-semibold px-2 py-0.5 rounded">
              Real-time Preview
            </span>
          </div>

          {/* Simulated Mobile Feed Card */}
          <div className="bg-white rounded-xl border border-slate-300 shadow-md overflow-hidden max-w-sm mx-auto">
            {/* Post Header */}
            <div className="p-3.5 flex items-center justify-between border-b border-slate-100">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-full bg-blue-700 flex items-center justify-center text-white text-xs font-bold">
                  YM
                </div>
                <div>
                  <div className="flex items-center space-x-1">
                    <span className="text-xs font-bold text-slate-900">Youth Advocacy Team</span>
                    <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                  </div>
                  <span className="text-[10px] text-slate-400">{scenario.location} • Just now</span>
                </div>
              </div>
            </div>

            {/* Post Copy */}
            <div className="p-3.5 space-y-2 text-xs text-slate-800 leading-relaxed">
              <p className="whitespace-pre-line">
                {data.post || 'Your campaign post copy will preview here as you type...'}
              </p>
              {data.hashtags && (
                <p className="text-blue-600 font-mono text-[11px]">
                  {data.hashtags}
                </p>
              )}
            </div>

            {/* Visual Graphic Banner (Mock Slogan Card) */}
            <div className="bg-gradient-to-br from-blue-800 via-indigo-900 to-slate-900 text-white p-5 text-center relative overflow-hidden">
              <div className="text-[10px] uppercase tracking-wider text-emerald-300 font-bold mb-1">
                {scenario.category}
              </div>
              <p className="text-sm sm:text-base font-extrabold leading-tight text-white mb-3">
                "{data.slogan || 'Your Campaign Slogan Here'}"
              </p>
              <div className="inline-block bg-white/10 backdrop-blur-xs px-2.5 py-1 rounded text-[10px] text-blue-200">
                #KabataanParaSaBayan
              </div>
            </div>

            {/* Call to action bar in mockup */}
            {data.cta && (
              <div className="bg-blue-50 px-3.5 py-2.5 border-t border-blue-100 flex items-center justify-between">
                <div className="text-[11px] font-bold text-blue-900 truncate mr-2">
                  👉 {data.cta}
                </div>
                <span className="shrink-0 text-[10px] font-bold bg-blue-600 text-white px-2 py-1 rounded shadow-2xs">
                  Take Action
                </span>
              </div>
            )}

            {/* Engagement buttons */}
            <div className="p-3 border-t border-slate-100 flex items-center justify-between text-slate-500 text-xs">
              <div className="flex items-center space-x-4">
                <span className="flex items-center space-x-1 hover:text-rose-600 cursor-pointer">
                  <Heart className="w-4 h-4" />
                  <span className="text-[11px]">1.2k</span>
                </span>
                <span className="flex items-center space-x-1 hover:text-blue-600 cursor-pointer">
                  <MessageCircle className="w-4 h-4" />
                  <span className="text-[11px]">348</span>
                </span>
                <span className="flex items-center space-x-1 hover:text-emerald-600 cursor-pointer">
                  <Share2 className="w-4 h-4" />
                  <span className="text-[11px]">520</span>
                </span>
              </div>
              <Bookmark className="w-4 h-4 cursor-pointer hover:text-slate-800" />
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex justify-between items-center pt-2">
        <button
          type="button"
          onClick={onBack}
          className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-100 flex items-center space-x-2 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to ICT Solution</span>
        </button>

        <button
          type="button"
          disabled={!isFormValid}
          onClick={onNext}
          className={`px-6 py-3 rounded-xl font-bold text-xs sm:text-sm flex items-center space-x-2 shadow-xs transition-all ${
            isFormValid
              ? 'bg-blue-700 hover:bg-blue-800 text-white cursor-pointer hover:shadow-md'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed'
          }`}
        >
          <span>Save & Proceed to Phase 5: Digital Ethics</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
