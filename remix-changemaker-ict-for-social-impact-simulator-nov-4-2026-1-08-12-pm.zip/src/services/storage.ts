import { AssessmentRecord } from '../types/simulator';

const STORAGE_KEY = 'changemaker_student_records_v1';
const CURRENT_SESSION_KEY = 'changemaker_active_session_v1';

// Seed initial realistic DepEd Senior High School records if empty
const DEMO_RECORDS: AssessmentRecord[] = [
  {
    id: 'rec-001',
    timestamp: new Date(Date.now() - 86400000 * 3).toISOString(),
    studentName: 'Juan Miguel Santos',
    section: 'Grade 11 - STEM A (Newton)',
    studentNumber: '2026-11042',
    scenarioTitle: 'Silencing the Screams: Anti-Cyberbullying Initiative',
    scores: {
      problemAnalysis: 14.5,
      researchSkills: 19.0,
      solutionDesign: 19.5,
      contentCreation: 14.5,
      ethics: 19.0,
      reflection: 9.5,
      total: 96.0,
      percentage: 96,
      performanceLevel: 'Outstanding',
    },
    responses: {
      phase1: {
        mainIssue: 'Anonymous cyberbullying and character defamation on a school-associated freedom wall Facebook page leading to student trauma.',
        stakeholders: 'Targeted students (Bianca), anonymous administrators, guidance counselors, SSLG, parents, and school administration.',
        consequences: 'Increased dropout rates, severe psychological distress, potential retaliatory cyber-attacks, and compromised school reputation.',
      },
      phase2: {
        evaluations: {},
        verificationMethods: 'Lateral reading across accredited news sources, checking official DepEd portals, cross-referencing claims with fact-checkers like VERA Files and Rappler, and reverse image search.',
      },
      phase3: {
        platform: 'Educational Chatbot',
        justification: 'A confidential Messenger chatbot provides 24/7 accessible guidance, anonymous reporting triage, and immediate escalation to certified guidance counselors.',
        audience: 'Junior and Senior High School students aged 13-18 who actively use Facebook Messenger and require confidential non-judgmental assistance.',
        outcomes: 'At least 80% reduction in unaddressed cyberbullying reports and establishment of a trusted digital bystander support channel.',
      },
      phase4: {
        slogan: 'Ligtas ang Bawat Tipa: Piliin ang Pagkalinga sa Social Media',
        post: 'Hindi biro ang pananakit sa likod ng keyboard. Bago mag-comment o mag-share ng screenshot, tanungin ang sarili: Makatutulong ba ito o makasisira ng buhay ng kapwa mo mag-aaral? Be an upstander, not an abusive bystander.',
        cta: 'I-report nang ligtas at kumpidensyal ang anumang kaso ng cyber-harassment sa ating school chatbot hotline.',
        hashtags: '#LigtasNaCampus #CyberSafetyPH #EmpTechForGood #DepEdChildProtection',
        caption: 'Alamin ang 4 na senyales ng cyberbullying at kung paano protektahan ang kapwa mag-aaral nang may malasakit at pananagutan.',
      },
      phase5: {
        dilemmas: {},
      },
      phase6: {
        essay: 'Information and Communications Technology is a double-edged sword that can either tear apart community trust or unite citizens to solve pressing social challenges. In our school and barangay, responsible ICT use means moving beyond passive entertainment to intentional civic advocacy. When we practice critical thinking before clicking, verify our sources through lateral reading, and protect our classmates data privacy under Republic Act 10173, we transform social platforms into instruments of empowerment. Digital citizenship is not simply avoiding cybercrime; it is actively championing empathy, truth, and community mobilization. As Senior High School students, we must lead by example—producing ethical multimedia that amplifies marginalized voices, educates our families on digital literacy, and builds an inclusive, resilient community for all.',
      },
    },
    completedAt: new Date(Date.now() - 86400000 * 3).toLocaleString('en-PH', { dateStyle: 'medium', timeStyle: 'short' }),
    aiFeedback: 'Exemplary project synthesis demonstrating mature understanding of digital ethics, peer support systems, and K-12 ICT competencies.',
  },
  {
    id: 'rec-002',
    timestamp: new Date(Date.now() - 86400000 * 2).toISOString(),
    studentName: 'Maria Sophia Dela Cruz',
    section: 'Grade 12 - HUMSS B (Rizal)',
    studentNumber: '2026-12089',
    scenarioTitle: 'Infodemic Defense: Combating Online Health & Community Hoaxes',
    scores: {
      problemAnalysis: 13.5,
      researchSkills: 18.0,
      solutionDesign: 17.5,
      contentCreation: 14.0,
      ethics: 18.0,
      reflection: 9.0,
      total: 90.0,
      percentage: 90,
      performanceLevel: 'Outstanding',
    },
    responses: {
      phase1: {
        mainIssue: 'Viral fake news regarding drinking water contamination in Marikina causing panic, hoarding, and financial exploitation.',
        stakeholders: 'Barangay residents, senior citizens, City Health Office, sari-sari store owners, and water refilling stations.',
        consequences: 'Artificial water shortage, economic strain on low-income families buying fake remedies, and erosion of trust in public health.',
      },
      phase2: { evaluations: {}, verificationMethods: 'Consulting City Health Office bulletins, verifying laboratory test certificates, and checking IFCN fact-checking databases.' },
      phase3: {
        platform: 'Infographic Campaign',
        justification: 'Visually engaging Tagalog infographics can be easily printed for barangay halls and shared directly in neighborhood Viber/Facebook groups.',
        audience: 'Households, parents, and senior citizens who frequently rely on forwarded social media visuals.',
        outcomes: 'Debunking the viral hoax in 90% of neighborhood groups and restoring trust in municipal drinking water testing.',
      },
      phase4: {
        slogan: 'Tubig ay Buhay, Huwag Ikalat ang Pekeng Balita!',
        post: 'Tigil muna bago i-forward! Kinumpirma ng Marikina City Health Office na 100% ligtas inumin ang ating tubig sa gripo. Huwag magpaloko sa mga pekeng gamot sa TikTok shop.',
        cta: 'I-check ang opisyal na water quality test results sa Marikina City portal o bisitahin ang inyong Barangay Health Center.',
        hashtags: '#FactCheckMarikina #LigtasNaTubig #HealthLiteracyPH',
        caption: 'Tatlong hakbang para matukoy kung peke ang nabasang health advisory sa social media bago maniwala.',
      },
      phase5: { dilemmas: {} },
      phase6: {
        essay: 'ICT is our generation’s most powerful megaphone for civic empowerment. In our community of Marikina, where floods and rumors spread with equal speed, ethical technology use is literally a matter of public health and safety. Responsible ICT starts with the habit of pause and verify: pausing before sharing unconfirmed sensational posts, verifying with certified government and scientific authorities, and educating our relatives with compassion rather than arrogance. By creating accessible visual infographics and debunking tools, youth can bridge the digital divide between complex scientific data and grassroots families. Social change occurs when digital tools are harnessed to protect vulnerable citizens, uphold truth, and foster collective resilience in the face of modern infodemics.',
      },
    },
    completedAt: new Date(Date.now() - 86400000 * 2).toLocaleString('en-PH', { dateStyle: 'medium', timeStyle: 'short' }),
    aiFeedback: 'Strong analytical skills demonstrated in debunking health disinformation and designing audience-tailored infographic interventions.',
  },
  {
    id: 'rec-003',
    timestamp: new Date(Date.now() - 86400000 * 1).toISOString(),
    studentName: 'Angelo Rafael Dizon',
    section: 'Grade 11 - TVL ICT (Turing)',
    studentNumber: '2026-11531',
    scenarioTitle: 'Resilient Barangay: Early Warning & Flood Action Network',
    scores: {
      problemAnalysis: 13.0,
      researchSkills: 17.0,
      solutionDesign: 18.0,
      contentCreation: 13.5,
      ethics: 16.5,
      reflection: 8.5,
      total: 86.5,
      percentage: 87,
      performanceLevel: 'Very Satisfactory',
    },
    responses: {
      phase1: {
        mainIssue: 'Ineffective flood warnings and viral dam hoaxes causing delayed evacuation and panic in riverbank communities.',
        stakeholders: 'Kasiglahan Village residents, MDRRMO, PAGASA, rescue volunteers, and Sangguniang Kabataan.',
        consequences: 'Calamity casualties, stranded families on rooftops, blocked rescue logistics, and panic-driven traffic jams.',
      },
      phase2: { evaluations: {}, verificationMethods: 'Tracking DOST-PAGASA Doppler radars, Project NOAH hazard maps, and direct MDRRMO two-way radio channels.' },
      phase3: {
        platform: 'Mobile App',
        justification: 'An offline-capable Progressive Web App provides cached evacuation maps, river gauge telemetry, and emergency siren notifications without requiring heavy cellular data.',
        audience: 'Barangay rescue volunteers, youth leaders, and household heads in flood-prone riverbanks.',
        outcomes: 'Zero flood fatalities and 100% timely pre-emptive evacuation before critical river red alerts.',
      },
      phase4: {
        slogan: 'Ligtas ang May Alam: Alerto sa Bawat Pagbaha',
        post: 'Huwag nang hintaying umabot ang baha sa bubong! Kapag nag-anunsyo ang MDRRMO ng Red Alert, mag-evacuate agad sa itinalagang Southville evacuation shelter.',
        cta: 'I-download ang offline evacuation guide at i-save ang emergency hotlines sa inyong telepono ngayon.',
        hashtags: '#DisasterResiliencePH #AlertMontalban #ProjectNOAH #LigtasBayan',
        caption: 'Gabay sa tatlong antas ng babala sa pagbaha: Dilaw (Maghanda), Kahel (Magbantay), at Pula (Lumikas Agad).',
      },
      phase5: { dilemmas: {} },
      phase6: {
        essay: 'Disaster preparedness in the Philippines requires not just concrete seawalls or sirens, but smart digital communication infrastructures. As ICT students, we have the technical capability and civic responsibility to turn data into life-saving action. During typhoon season, when cellular towers are strained and panic brews on social media, responsible technology use means sharing only verified hydrological data from DOST-PAGASA and Project NOAH. ICT creates positive change when it democratizes access to safety information, ensuring that even families with basic mobile phones receive timely evacuation warnings. Our technology must serve human life and safety above clicks, virality, or political gain.',
      },
    },
    completedAt: new Date(Date.now() - 86400000 * 1).toLocaleString('en-PH', { dateStyle: 'medium', timeStyle: 'short' }),
    aiFeedback: 'Solid technical proposal focusing on offline resilience and life-saving risk communication.',
  },
  {
    id: 'rec-004',
    timestamp: new Date(Date.now() - 43200000).toISOString(),
    studentName: 'Bea Patricia Alcantara',
    section: 'Grade 12 - ABM A (Galbraith)',
    studentNumber: '2026-12154',
    scenarioTitle: 'Zero Waste Barangay: ICT for Community Plastic Recycling',
    scores: {
      problemAnalysis: 12.0,
      researchSkills: 16.5,
      solutionDesign: 16.0,
      contentCreation: 12.5,
      ethics: 16.0,
      reflection: 8.0,
      total: 81.0,
      percentage: 81,
      performanceLevel: 'Satisfactory',
    },
    responses: {
      phase1: {
        mainIssue: 'Massive single-use sachet waste accumulation choking drainage channels in Bagong Silang.',
        stakeholders: 'Households, sari-sari store owners, informal waste pickers, junk shops, and barangay solid waste committee.',
        consequences: 'Severe flash flooding, leptospirosis outbreaks, and loss of economic opportunities for informal waste collectors.',
      },
      phase2: { evaluations: {}, verificationMethods: 'Cross-checking DENR solid waste reports, RA 9003 provisions, and municipal collection schedules.' },
      phase3: {
        platform: 'Community Reporting Platform',
        justification: 'A lightweight web-based reporting and drop-off map connecting households, junk shops, and barangay eco-brick collectors.',
        audience: 'Sari-sari store owners, youth recyclers, and barangay garbage collection crews.',
        outcomes: 'At least 30% increase in collected plastic sachets upcycled into community building blocks.',
      },
      phase4: {
        slogan: 'Sachet Mo, Ibalik Mo: Para sa Malinis na Bagong Silang',
        post: 'Alam mo ba na ang isang shampoo sachet ay tumatagal ng daan-daang taon sa ating mga estero? Huwag itapon sa kanal—ipunin sa plastic bottle para maging eco-brick!',
        cta: 'Dalhin ang inyong naipong malinis na plastic wrappers sa Barangay Hall tuwing Sabado para sa grocery exchange!',
        hashtags: '#ZeroWastePH #EcoBrickTayo #BantayKalikasan #CleanCaloocan',
        caption: 'Paraan ng tamang paggawa ng matibay na eco-brick gamit ang mga pinatuyong sachet at plastic bottles.',
      },
      phase5: { dilemmas: {} },
      phase6: {
        essay: 'Environmental conservation in dense urban areas like Caloocan cannot succeed without community participation and digital coordination. ICT enables everyday citizens to see the real impact of their waste habits through transparent community mapping and collection schedules. When we use social media to showcase youth eco-brick initiatives instead of mindless gossip, we foster civic pride and environmental accountability. Responsible technology use also entails respecting the dignity of our informal waste workers and ensuring that ecological campaigns do not shame low-income families who depend on affordable sachet goods. By leveraging digital tools to create practical waste exchange systems, we prove that youth innovation can drive sustainable community development.',
      },
    },
    completedAt: new Date(Date.now() - 43200000).toLocaleString('en-PH', { dateStyle: 'medium', timeStyle: 'short' }),
    aiFeedback: 'Satisfactory plan highlighting the intersection of environmental economics, waste worker dignity, and digital coordination.',
  },
  {
    id: 'rec-005',
    timestamp: new Date(Date.now() - 21600000).toISOString(),
    studentName: 'Christian Jay Flores',
    section: 'Grade 11 - STEM B (Galileo)',
    studentNumber: '2026-11098',
    scenarioTitle: 'MindMatters: De-Stigmatizing Youth Mental Health & Digital Well-being',
    scores: {
      problemAnalysis: 11.5,
      researchSkills: 15.0,
      solutionDesign: 15.5,
      contentCreation: 12.0,
      ethics: 15.0,
      reflection: 7.5,
      total: 76.5,
      percentage: 77,
      performanceLevel: 'Fairly Satisfactory',
    },
    responses: {
      phase1: {
        mainIssue: 'Academic burnout and severe mental health stigma preventing students from seeking guidance support.',
        stakeholders: 'Students, guidance counselors, parents, teachers, and peer facilitators.',
        consequences: 'Increased absenteeism, untreated clinical depression, and resort to unmoderated toxic forums.',
      },
      phase2: { evaluations: {}, verificationMethods: 'Checking DOH mental health protocols, RA 11036 guidelines, and certified hospital contacts.' },
      phase3: {
        platform: 'Social Media Campaign',
        justification: 'Awareness graphics and short videos on TikTok and Instagram to normalize talking about stress and mental wellness.',
        audience: 'Senior High School learners facing exam pressure and academic anxiety.',
        outcomes: 'Promoting awareness of NCMH hotline 1553 and reducing stigma among classmates.',
      },
      phase4: {
        slogan: 'Hinga Muna: Hindi Ka Nag-iisa sa Laban',
        post: 'Normal lang mapagod, hindi kasalanan ang magpahinga. Kung nararamdaman mo ang labis na bigat, may mga handang makinig sa ating school guidance counseling team.',
        cta: 'Tumawag nang libre sa DOH Mental Health Crisis Hotline 1553 o bisitahin ang Guidance Office.',
        hashtags: '#MindMattersPH #MentalHealthAwareness #HingaKaMuna #YouthWellbeing',
        caption: 'Mga simpleng pampakalmang hakbang kapag inaatake ng kaba at anxiety sa eskwelahan.',
      },
      phase5: { dilemmas: {} },
      phase6: {
        essay: 'Mental health is an important topic that young people should discuss openly. ICT helps connect students who feel lonely and gives them access to tips and helplines. Responsible use of technology means we should not post rude comments on people’s problems or share bad advice. We should share verified helplines like NCMH and encourage our friends when they are stressed. Technology can make our community a kinder place when used for empathy.',
      },
    },
    completedAt: new Date(Date.now() - 21600000).toLocaleString('en-PH', { dateStyle: 'medium', timeStyle: 'short' }),
    aiFeedback: 'Fairly satisfactory submission. Expand on audience profiling and practical digital ethics boundaries.',
  },
];

export function getStudentAssessments(): AssessmentRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      // Seed initial demo data so teachers immediately have records
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEMO_RECORDS));
      return DEMO_RECORDS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : DEMO_RECORDS;
  } catch (err) {
    console.error('Error reading assessments from localStorage:', err);
    return DEMO_RECORDS;
  }
}

export function saveStudentAssessment(record: AssessmentRecord): void {
  try {
    const records = getStudentAssessments();
    // Prepend new record so latest appears first
    const updated = [record, ...records.filter((r) => r.id !== record.id)];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Error saving assessment to localStorage:', err);
  }
}

export function deleteStudentAssessment(id: string): void {
  try {
    const records = getStudentAssessments();
    const filtered = records.filter((r) => r.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
  } catch (err) {
    console.error('Error deleting student record:', err);
  }
}

export function deleteClassAssessments(section: string): void {
  try {
    const records = getStudentAssessments();
    const filtered = records.filter((r) => r.section !== section);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
  } catch (err) {
    console.error('Error clearing class records:', err);
  }
}

export function clearAllAssessments(): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify([]));
  } catch (err) {
    console.error('Error clearing all assessments:', err);
  }
}

export function restoreDefaultRecords(): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(DEMO_RECORDS));
  } catch (err) {
    console.error('Error restoring default records:', err);
  }
}

// Active Assessment Session Persistence (so student doesn't lose progress on page refresh)
export function getActiveSession(): any | null {
  try {
    const raw = localStorage.getItem(CURRENT_SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function saveActiveSession(data: any): void {
  try {
    localStorage.setItem(CURRENT_SESSION_KEY, JSON.stringify(data));
  } catch (e) {
    console.error('Error saving session progress:', e);
  }
}

export function clearActiveSession(): void {
  try {
    localStorage.removeItem(CURRENT_SESSION_KEY);
  } catch (e) {
    console.error('Error clearing session:', e);
  }
}

// Export CSV according to prompt specification:
// Columns: Name, Section, Date, Problem Analysis, Research Skills, ICT Solution, Content Creation, Ethics, Reflection, Total, Percentage, Performance Level
// File name: assessment_results.csv
export function exportAssessmentCSV(records: AssessmentRecord[], isExcelCompatible = true): void {
  const headers = [
    'Name',
    'Section',
    'Date',
    'Problem Analysis',
    'Research Skills',
    'ICT Solution',
    'Content Creation',
    'Ethics',
    'Reflection',
    'Total',
    'Percentage',
    'Performance Level',
  ];

  const rows = records.map((r) => {
    return [
      escapeCSV(r.studentName),
      escapeCSV(r.section),
      escapeCSV(r.completedAt || new Date(r.timestamp).toLocaleDateString()),
      r.scores.problemAnalysis.toFixed(1),
      r.scores.researchSkills.toFixed(1),
      r.scores.solutionDesign.toFixed(1),
      r.scores.contentCreation.toFixed(1),
      r.scores.ethics.toFixed(1),
      r.scores.reflection.toFixed(1),
      r.scores.total.toFixed(1),
      `${r.scores.percentage}%`,
      escapeCSV(r.scores.performanceLevel),
    ].join(',');
  });

  const csvContent = [headers.join(','), ...rows].join('\r\n');

  // If Excel-compatible, prepend UTF-8 BOM so Excel decodes Philippine names and special accents cleanly
  const blob = new Blob(
    [isExcelCompatible ? '\uFEFF' + csvContent : csvContent],
    { type: 'text/csv;charset=utf-8;' }
  );

  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', 'assessment_results.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function escapeCSV(val: string): string {
  if (!val) return '""';
  const str = String(val).replace(/"/g, '""');
  return `"${str}"`;
}
