import { AssessmentResponses, PerformanceLevel, ScenarioData, ScoreBreakdown } from '../types/simulator';

export function calculatePerformanceLevel(totalScore: number): PerformanceLevel {
  if (totalScore >= 90) return 'Outstanding';
  if (totalScore >= 85) return 'Very Satisfactory';
  if (totalScore >= 80) return 'Satisfactory';
  if (totalScore >= 75) return 'Fairly Satisfactory';
  return 'Needs Improvement';
}

export function evaluateStudentAssessment(
  responses: AssessmentResponses,
  scenario: ScenarioData
): ScoreBreakdown {
  // 1. Phase 1: Problem Analysis (Max 15)
  // Accuracy (5), Social impact (5), Critical thinking (5)
  let p1Score = 0;
  const q1 = responses.phase1.mainIssue.trim();
  const q2 = responses.phase1.stakeholders.trim();
  const q3 = responses.phase1.consequences.trim();

  // Accuracy (Max 5)
  if (q1.length >= 80) {
    p1Score += 5;
  } else if (q1.length >= 40) {
    p1Score += 4;
  } else if (q1.length >= 15) {
    p1Score += 3;
  } else if (q1.length > 0) {
    p1Score += 1;
  }

  // Social Impact awareness (Max 5)
  if (q2.length >= 80) {
    p1Score += 5;
  } else if (q2.length >= 40) {
    p1Score += 4;
  } else if (q2.length >= 15) {
    p1Score += 3;
  } else if (q2.length > 0) {
    p1Score += 1;
  }

  // Critical Thinking / Consequences (Max 5)
  if (q3.length >= 80) {
    p1Score += 5;
  } else if (q3.length >= 40) {
    p1Score += 4;
  } else if (q3.length >= 15) {
    p1Score += 3;
  } else if (q3.length > 0) {
    p1Score += 1;
  }

  p1Score = Math.min(15, p1Score);

  // 2. Phase 2: Online Research Skills (Max 20)
  // Source evaluation (7), Critical analysis (7), Verification strategy (6)
  let p2Evaluation = 0;
  let p2Analysis = 0;
  let p2Verification = 0;

  scenario.researchSources.forEach((src) => {
    const userEval = responses.phase2.evaluations[src.id];
    if (userEval) {
      const correctClassification =
        (src.isCredible && userEval.userCredibility === 'credible') ||
        (!src.isCredible && userEval.userCredibility === 'questionable');

      if (correctClassification) {
        p2Evaluation += 1.75; // 4 sources * 1.75 = 7 pts
      } else {
        p2Evaluation += 0.5; // partial for attempting
      }

      // Check reasoning / critical analysis
      const justLen = (userEval.justification || '').trim().length;
      const redFlagsLen = (userEval.identifiedRedFlags || '').trim().length;
      if (justLen >= 40 || redFlagsLen >= 30) {
        p2Analysis += 1.75;
      } else if (justLen >= 15 || redFlagsLen >= 10) {
        p2Analysis += 1.0;
      } else if (justLen > 0) {
        p2Analysis += 0.5;
      }
    }
  });

  // Verification strategy (Max 6)
  const vMethods = responses.phase2.verificationMethods.trim();
  if (vMethods.length >= 120) {
    p2Verification = 6;
  } else if (vMethods.length >= 60) {
    p2Verification = 4.5;
  } else if (vMethods.length >= 25) {
    p2Verification = 3;
  } else if (vMethods.length > 0) {
    p2Verification = 1.5;
  }

  const p2Score = Math.min(20, Math.round((p2Evaluation + p2Analysis + p2Verification) * 10) / 10);

  // 3. Phase 3: ICT Solution Design (Max 20)
  // Relevance (7), Audience profiling (7), Feasibility (6)
  let p3Relevance = 0;
  let p3Audience = 0;
  let p3Feasibility = 0;

  const just = responses.phase3.justification.trim();
  const aud = responses.phase3.audience.trim();
  const out = responses.phase3.outcomes.trim();

  // Relevance
  if (just.length >= 100) p3Relevance = 7;
  else if (just.length >= 50) p3Relevance = 5.5;
  else if (just.length >= 20) p3Relevance = 4;
  else if (just.length > 0) p3Relevance = 2;

  // Audience Profiling
  if (aud.length >= 100) p3Audience = 7;
  else if (aud.length >= 50) p3Audience = 5.5;
  else if (aud.length >= 20) p3Audience = 4;
  else if (aud.length > 0) p3Audience = 2;

  // Feasibility & Outcomes
  if (out.length >= 80) p3Feasibility = 6;
  else if (out.length >= 40) p3Feasibility = 4.5;
  else if (out.length >= 15) p3Feasibility = 3;
  else if (out.length > 0) p3Feasibility = 1.5;

  const p3Score = Math.min(20, Math.round((p3Relevance + p3Audience + p3Feasibility) * 10) / 10);

  // 4. Phase 4: Content Creation Challenge (Max 15)
  // Persuasiveness (4), Creativity (4), Clarity (4), Audience suitability (3)
  let p4Score = 0;
  const slogan = responses.phase4.slogan.trim();
  const post = responses.phase4.post.trim();
  const cta = responses.phase4.cta.trim();
  const hashtags = responses.phase4.hashtags.trim();
  const caption = responses.phase4.caption.trim();

  // Slogan & Creativity
  if (slogan.length >= 12) p4Score += 3.5;
  else if (slogan.length > 0) p4Score += 2;

  // Social Post & Persuasiveness
  if (post.length >= 90) p4Score += 4;
  else if (post.length >= 40) p4Score += 3;
  else if (post.length > 0) p4Score += 1.5;

  // Call-To-Action & Clarity
  if (cta.length >= 20) p4Score += 3.5;
  else if (cta.length > 0) p4Score += 2;

  // Hashtags & Audience Suitability
  if (hashtags.includes('#') && hashtags.length >= 10) p4Score += 2;
  else if (hashtags.length > 0) p4Score += 1;

  // Infographic Caption
  if (caption.length >= 40) p4Score += 2;
  else if (caption.length > 0) p4Score += 1;

  p4Score = Math.min(15, Math.round(p4Score * 10) / 10);

  // 5. Phase 5: Digital Ethics Simulation (Max 20)
  // 5 dilemmas * 4 points each = 20 pts
  let p5Score = 0;
  scenario.dilemmas.forEach((dil) => {
    const userDil = responses.phase5.dilemmas[dil.id];
    if (userDil) {
      let dilemmaPts = 0;
      // Match decision
      if (userDil.decision === dil.idealDecision) {
        dilemmaPts += 2.5; // ideal decision
      } else if (
        (dil.idealDecision === 'Reject' && userDil.decision === 'Modify') ||
        (dil.idealDecision === 'Modify' && userDil.decision === 'Approve') ||
        (dil.idealDecision === 'Modify' && userDil.decision === 'Reject')
      ) {
        dilemmaPts += 1.5; // defensible alternative
      } else {
        dilemmaPts += 0.5; // attempted
      }

      // Justification
      const justLen = (userDil.justification || '').trim().length;
      if (justLen >= 60) dilemmaPts += 1.5;
      else if (justLen >= 25) dilemmaPts += 1.0;
      else if (justLen > 0) dilemmaPts += 0.5;

      p5Score += Math.min(4, dilemmaPts);
    }
  });
  p5Score = Math.min(20, Math.round(p5Score * 10) / 10);

  // 6. Phase 6: Reflection (Max 10)
  // Prompt: "How can ICT be used responsibly to create positive social change in your community?"
  // Required: 150 - 250 words
  // Insight (4), Understanding (3), Personal relevance (3)
  const essay = responses.phase6.essay.trim();
  const wordCount = essay ? essay.split(/\s+/).filter(Boolean).length : 0;

  let p6Score = 0;
  if (wordCount >= 150 && wordCount <= 280) {
    // Ideal range
    p6Score = 10;
  } else if (wordCount >= 110) {
    p6Score = 8.5;
  } else if (wordCount >= 70) {
    p6Score = 7.0;
  } else if (wordCount >= 30) {
    p6Score = 5.0;
  } else if (wordCount > 0) {
    p6Score = 3.0;
  }

  // Calculate totals
  const total = Math.min(100, Math.round((p1Score + p2Score + p3Score + p4Score + p5Score + p6Score) * 10) / 10);
  const percentage = Math.round((total / 100) * 100);
  const performanceLevel = calculatePerformanceLevel(total);

  return {
    problemAnalysis: p1Score,
    researchSkills: p2Score,
    solutionDesign: p3Score,
    contentCreation: p4Score,
    ethics: p5Score,
    reflection: p6Score,
    total,
    percentage,
    performanceLevel,
  };
}
