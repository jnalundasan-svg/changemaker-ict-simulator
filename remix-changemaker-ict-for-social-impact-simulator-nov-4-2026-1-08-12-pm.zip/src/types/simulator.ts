export type AdvocacyTopicId =
  | 'cyberbullying'
  | 'misinformation'
  | 'plastic_waste'
  | 'disaster_preparedness'
  | 'mental_health'
  | 'internet_addiction'
  | 'copyright'
  | 'environmental_conservation'
  | 'animal_welfare'
  | 'youth_volunteers';

export interface ResearchSource {
  id: string;
  title: string;
  publisher: string;
  url: string;
  author: string;
  publishDate: string;
  excerpt: string;
  type: 'article' | 'social_post' | 'screenshot' | 'website_snippet';
  isCredible: boolean;
  credibilityReasons: string;
  misinformationFlags: string[];
}

export interface EthicsDilemma {
  id: string;
  situation: string;
  context: string;
  idealDecision: 'Approve' | 'Reject' | 'Modify';
  ethicalPrinciples: string[];
}

export interface ScenarioData {
  id: AdvocacyTopicId;
  title: string;
  category: string;
  location: string;
  communityContext: string;
  narrative: string; // 250 - 400 words localized Philippine context
  keyStakeholders: string[];
  coreChallenge: string;
  researchSources: ResearchSource[];
  dilemmas: EthicsDilemma[];
}

export interface StudentInfo {
  name: string;
  section: string;
  studentNumber?: string;
  dateTime: string;
}

export interface Phase1Response {
  mainIssue: string;
  stakeholders: string;
  consequences: string;
}

export interface SourceEvaluationResponse {
  sourceId: string;
  userCredibility: 'credible' | 'questionable';
  justification: string;
  identifiedRedFlags: string;
}

export interface Phase2Response {
  evaluations: Record<string, SourceEvaluationResponse>;
  verificationMethods: string;
}

export type ICTPlatform =
  | 'Website'
  | 'Social Media Campaign'
  | 'Mobile App'
  | 'Educational Chatbot'
  | 'Infographic Campaign'
  | 'Community Reporting Platform';

export interface Phase3Response {
  platform: ICTPlatform;
  justification: string;
  audience: string;
  outcomes: string;
}

export interface Phase4Response {
  slogan: string;
  post: string;
  cta: string;
  hashtags: string;
  caption: string;
}

export interface DilemmaResponse {
  decision: 'Approve' | 'Reject' | 'Modify';
  justification: string;
}

export interface Phase5Response {
  dilemmas: Record<string, DilemmaResponse>;
}

export interface Phase6Response {
  essay: string;
}

export interface AssessmentResponses {
  phase1: Phase1Response;
  phase2: Phase2Response;
  phase3: Phase3Response;
  phase4: Phase4Response;
  phase5: Phase5Response;
  phase6: Phase6Response;
}

export interface ScoreBreakdown {
  problemAnalysis: number; // Max 15
  researchSkills: number;   // Max 20
  solutionDesign: number;   // Max 20
  contentCreation: number;  // Max 15
  ethics: number;           // Max 20
  reflection: number;       // Max 10
  total: number;            // Max 100
  percentage: number;       // 0 - 100
  performanceLevel: PerformanceLevel;
  feedbackNotes?: string;
}

export type PerformanceLevel =
  | 'Outstanding'
  | 'Very Satisfactory'
  | 'Satisfactory'
  | 'Fairly Satisfactory'
  | 'Needs Improvement';

export interface AssessmentRecord {
  id: string;
  timestamp: string;
  studentName: string;
  section: string;
  studentNumber?: string;
  scenarioTitle: string;
  scores: ScoreBreakdown;
  responses: AssessmentResponses;
  completedAt: string;
  aiFeedback?: string;
}
