/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { StudentInfoStep } from './components/StudentInfoStep';
import { Phase1ProblemAnalysis } from './components/Phase1ProblemAnalysis';
import { Phase2ResearchSkills } from './components/Phase2ResearchSkills';
import { Phase3SolutionDesign } from './components/Phase3SolutionDesign';
import { Phase4ContentCreation } from './components/Phase4ContentCreation';
import { Phase5DigitalEthics } from './components/Phase5DigitalEthics';
import { Phase6Reflection } from './components/Phase6Reflection';
import { CertificateResults } from './components/CertificateResults';
import { TeacherDashboard } from './components/TeacherDashboard';
import { ScenarioBriefModal } from './components/ScenarioBriefModal';

import { ADVOCACY_SCENARIOS } from './data/scenarios';
import {
  AssessmentRecord,
  AssessmentResponses,
  Phase1Response,
  Phase2Response,
  Phase3Response,
  Phase4Response,
  Phase5Response,
  Phase6Response,
  ScenarioData,
  StudentInfo,
} from './types/simulator';
import { evaluateStudentAssessment } from './services/scoringEngine';
import {
  clearActiveSession,
  getActiveSession,
  saveActiveSession,
  saveStudentAssessment,
} from './services/storage';

export default function App() {
  // App Phase: 0 = Info, 1..6 = Phases, 7 = Results/Certificate
  const [currentPhase, setCurrentPhase] = useState<number>(0);
  const [studentInfo, setStudentInfo] = useState<StudentInfo | null>(null);
  const [activeScenario, setActiveScenario] = useState<ScenarioData | null>(null);

  // Student Responses for all 6 phases
  const [phase1Data, setPhase1Data] = useState<Phase1Response>({
    mainIssue: '',
    stakeholders: '',
    consequences: '',
  });

  const [phase2Data, setPhase2Data] = useState<Phase2Response>({
    evaluations: {},
    verificationMethods: '',
  });

  const [phase3Data, setPhase3Data] = useState<Phase3Response>({
    platform: 'Website',
    justification: '',
    audience: '',
    outcomes: '',
  });

  const [phase4Data, setPhase4Data] = useState<Phase4Response>({
    slogan: '',
    post: '',
    cta: '',
    hashtags: '',
    caption: '',
  });

  const [phase5Data, setPhase5Data] = useState<Phase5Response>({
    dilemmas: {},
  });

  const [phase6Data, setPhase6Data] = useState<Phase6Response>({
    essay: '',
  });

  // Final Completed Record
  const [completedRecord, setCompletedRecord] = useState<AssessmentRecord | null>(null);

  // Loading state during final evaluation
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);

  // Modals
  const [isTeacherOpen, setIsTeacherOpen] = useState<boolean>(false);
  const [isScenarioModalOpen, setIsScenarioModalOpen] = useState<boolean>(false);

  // Check and restore existing in-progress session if any
  useEffect(() => {
    const saved = getActiveSession();
    if (saved && saved.studentInfo && saved.scenarioId) {
      const scenario = ADVOCACY_SCENARIOS.find((s) => s.id === saved.scenarioId) || ADVOCACY_SCENARIOS[0];
      setStudentInfo(saved.studentInfo);
      setActiveScenario(scenario);
      setCurrentPhase(saved.currentPhase || 1);
      if (saved.responses) {
        if (saved.responses.phase1) setPhase1Data(saved.responses.phase1);
        if (saved.responses.phase2) setPhase2Data(saved.responses.phase2);
        if (saved.responses.phase3) setPhase3Data(saved.responses.phase3);
        if (saved.responses.phase4) setPhase4Data(saved.responses.phase4);
        if (saved.responses.phase5) setPhase5Data(saved.responses.phase5);
        if (saved.responses.phase6) setPhase6Data(saved.responses.phase6);
      }
    }
  }, []);

  // Autosave status indicators
  const [lastSavedTime, setLastSavedTime] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Autosave session on every step update
  useEffect(() => {
    if (studentInfo && activeScenario && currentPhase >= 1 && currentPhase <= 6) {
      setIsSaving(true);
      saveActiveSession({
        studentInfo,
        scenarioId: activeScenario.id,
        currentPhase,
        responses: {
          phase1: phase1Data,
          phase2: phase2Data,
          phase3: phase3Data,
          phase4: phase4Data,
          phase5: phase5Data,
          phase6: phase6Data,
        },
      });

      const timer = setTimeout(() => {
        setIsSaving(false);
        setLastSavedTime(
          new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
          })
        );
      }, 300);

      return () => clearTimeout(timer);
    }
  }, [
    studentInfo,
    activeScenario,
    currentPhase,
    phase1Data,
    phase2Data,
    phase3Data,
    phase4Data,
    phase5Data,
    phase6Data,
  ]);

  // Start simulation with randomly selected scenario
  const handleStartSimulation = (info: StudentInfo) => {
    setStudentInfo(info);
    // Randomly select 1 of the 10 scenarios
    const randomIndex = Math.floor(Math.random() * ADVOCACY_SCENARIOS.length);
    const chosenScenario = ADVOCACY_SCENARIOS[randomIndex];
    setActiveScenario(chosenScenario);
    setCurrentPhase(1);
    // Open scenario brief on start so student gets the full narrative first
    setIsScenarioModalOpen(true);
  };

  // Submit and compute assessment
  const handleFinalSubmit = async () => {
    if (!studentInfo || !activeScenario) return;

    setIsEvaluating(true);

    const responses: AssessmentResponses = {
      phase1: phase1Data,
      phase2: phase2Data,
      phase3: phase3Data,
      phase4: phase4Data,
      phase5: phase5Data,
      phase6: phase6Data,
    };

    // Calculate official DepEd criterion scores
    const calculatedScores = evaluateStudentAssessment(responses, activeScenario);

    // Call server AI evaluation endpoint for authentic feedback
    let aiFeedbackText = '';
    try {
      const res = await fetch('/api/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName: studentInfo.name,
          scenario: activeScenario,
          responses,
          calculatedScores,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        aiFeedbackText = data.facilitatorNotes || '';
      }
    } catch (err) {
      console.warn('AI evaluation API unavailable, using calibrated rubric feedback:', err);
    }

    if (!aiFeedbackText) {
      aiFeedbackText = `Commendation: Outstanding effort in formulating your ${responses.phase3.platform} project for ${activeScenario.location}. Your problem analysis accurately reflected the key stakeholders, and your ethical decisions upheld digital citizenship and privacy standards.

Growth Pointer: Continue practicing lateral reading and verifying online claims using primary government and academic sources before public dissemination.

Adviser Closing: Mabuhay! Use your ICT skills as a tool for empathy, truth, and community transformation!`;
    }

    const newRecord: AssessmentRecord = {
      id: `rec-${Date.now().toString(36)}`,
      timestamp: new Date().toISOString(),
      studentName: studentInfo.name,
      section: studentInfo.section,
      studentNumber: studentInfo.studentNumber,
      scenarioTitle: activeScenario.title,
      scores: {
        ...calculatedScores,
        feedbackNotes: aiFeedbackText,
      },
      responses,
      completedAt: new Date().toLocaleString('en-PH', {
        dateStyle: 'medium',
        timeStyle: 'short',
      }),
      aiFeedback: aiFeedbackText,
    };

    // Persist permanently to local storage
    saveStudentAssessment(newRecord);
    clearActiveSession();

    setCompletedRecord(newRecord);
    setCurrentPhase(7); // View Certificate and results
    setIsEvaluating(false);
  };

  // Reset to start a new student assessment
  const handleRestart = () => {
    clearActiveSession();
    setStudentInfo(null);
    setActiveScenario(null);
    setCompletedRecord(null);
    setPhase1Data({ mainIssue: '', stakeholders: '', consequences: '' });
    setPhase2Data({ evaluations: {}, verificationMethods: '' });
    setPhase3Data({ platform: 'Website', justification: '', audience: '', outcomes: '' });
    setPhase4Data({ slogan: '', post: '', cta: '', hashtags: '', caption: '' });
    setPhase5Data({ dilemmas: {} });
    setPhase6Data({ essay: '' });
    setCurrentPhase(0);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-800">
      {/* Top Application Header */}
      <Header
        currentPhase={currentPhase}
        totalPhases={7}
        studentInfo={studentInfo}
        onOpenTeacher={() => setIsTeacherOpen(true)}
        onOpenScenarioModal={() => setIsScenarioModalOpen(true)}
        hasScenario={activeScenario !== null}
        scenarioTitle={activeScenario?.title}
        isCompleted={currentPhase === 7}
        lastSavedTime={lastSavedTime}
        isSaving={isSaving}
      />

      {/* Main Simulation Viewport */}
      <main className="flex-1">
        {currentPhase === 0 && <StudentInfoStep onStart={handleStartSimulation} />}

        {currentPhase === 1 && activeScenario && (
          <Phase1ProblemAnalysis
            scenario={activeScenario}
            data={phase1Data}
            onChange={setPhase1Data}
            onNext={() => setCurrentPhase(2)}
            onOpenBrief={() => setIsScenarioModalOpen(true)}
          />
        )}

        {currentPhase === 2 && activeScenario && (
          <Phase2ResearchSkills
            scenario={activeScenario}
            data={phase2Data}
            onChange={setPhase2Data}
            onNext={() => setCurrentPhase(3)}
            onBack={() => setCurrentPhase(1)}
          />
        )}

        {currentPhase === 3 && activeScenario && (
          <Phase3SolutionDesign
            scenario={activeScenario}
            data={phase3Data}
            onChange={setPhase3Data}
            onNext={() => setCurrentPhase(4)}
            onBack={() => setCurrentPhase(2)}
          />
        )}

        {currentPhase === 4 && activeScenario && (
          <Phase4ContentCreation
            scenario={activeScenario}
            data={phase4Data}
            onChange={setPhase4Data}
            onNext={() => setCurrentPhase(5)}
            onBack={() => setCurrentPhase(3)}
          />
        )}

        {currentPhase === 5 && activeScenario && (
          <Phase5DigitalEthics
            scenario={activeScenario}
            data={phase5Data}
            onChange={setPhase5Data}
            onNext={() => setCurrentPhase(6)}
            onBack={() => setCurrentPhase(4)}
          />
        )}

        {currentPhase === 6 && activeScenario && (
          <Phase6Reflection
            scenario={activeScenario}
            data={phase6Data}
            onChange={setPhase6Data}
            onSubmit={handleFinalSubmit}
            onBack={() => setCurrentPhase(5)}
            isEvaluating={isEvaluating}
          />
        )}

        {currentPhase === 7 && completedRecord && (
          <CertificateResults
            record={completedRecord}
            onRestart={handleRestart}
            onOpenTeacher={() => setIsTeacherOpen(true)}
          />
        )}
      </main>

      {/* Scenario Brief Modal (Accessible during any phase) */}
      <ScenarioBriefModal
        scenario={activeScenario}
        isOpen={isScenarioModalOpen}
        onClose={() => setIsScenarioModalOpen(false)}
      />

      {/* Teacher Dashboard Modal (Password protected) */}
      <TeacherDashboard isOpen={isTeacherOpen} onClose={() => setIsTeacherOpen(false)} />

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 px-4 text-center text-xs text-slate-500 print:hidden">
        <p>
          ChangeMaker: ICT for Social Impact Simulator • Senior High School Empowerment Technologies
        </p>
        <p className="text-[11px] text-slate-400 mt-0.5">
          Aligned with the Department of Education K-12 Curriculum on Digital Citizenship, Online Research, and ICT Advocacy.
        </p>
      </footer>
    </div>
  );
}
